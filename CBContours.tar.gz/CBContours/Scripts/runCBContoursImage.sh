#!/bin/sh




ERROR=$1;


NAME=$2;
TH=$3
MINSIZE=$4

WIDTH=$5

ALGO=$6

PATH_BASE=/home/kerautre/Sites/CBContours  ;


cd ${PATH_BASE};

export LD_LIBRARY_PATH=/usr/local/lib/;


if( test  $# -eq 9 )
then
  /usr/local/bin/pgm2freeman --min $TH --minSize $MINSIZE -i $NAME -selectContour $6 $7 $8 > /home/kerautre/Sites/CBContours/FichiersTmp/contour.fc 2> FichiersTmp/log2.txt; cat FichiersTmp/log2.txt| cut -f 3,4 -d " " > FichiersTmp/size.txt ;
else    
    /usr/local/bin/pgm2freeman --min $TH --minSize $MINSIZE -i $NAME  > /home/kerautre/Sites/CBContours/FichiersTmp/contour.fc 2> FichiersTmp/log22.txt; cat FichiersTmp/log2.txt| cut -f 3,4 -d " " > FichiersTmp/size.txt ;

fi

/usr/local/bin/freeman2sdp -f FichiersTmp/contour.fc > FichiersTmp/contour.sdp 2> FichiersTmp/log33.txt;

SIZE=$(cat FichiersTmp/size.txt);
/usr/local/bin/pgmTrans -setBlack 120 -setMinBlack 254 < $NAME > /tmp/tmp.pgm
convert /tmp/tmp.pgm FichiersTmp/imageFond.png;



if ( test ${ALGO} = "NASR" )
then
/usr/bin/arclinesegmentation -display 2 -color -1 -eP ${WIDTH} < FichiersTmp/contour.sdp -afficheImage imageFond.png ${SIZE}  > FichiersTmp/tmp.fig 2> FichiersTmp/log.txt
CONTOUR_SAMPLED=/tmp/sampling_reconstruction.txt;
fi

if  ( test ${ALGO} = "VC" )
then
/usr/local/bin/curvature_visualc -scale ${WIDTH} < FichiersTmp/contour.fc 2> FichiersTmp/log.txt | grep -v '#' | awk '{ if ($4 != 0) printf("%d %d \n", $6, $7); }' >  FichiersTmp/polygonVC.dat ;
/usr/local/bin/polygone2fig -enteteXFIG < FichiersTmp/polygonVC.dat -drawPolygon 1 2 0 1 -drawVertex 4 2 -drawImage imageFond.png ${SIZE} > FichiersTmp/tmp.fig; 
CONTOUR_SAMPLED=FichiersTmp/polygonVC.dat;
NB_POINTS=$(wc -l < FichiersTmp/polygonVC.dat );

fi

if  ( test ${ALGO} = "BCCA" -o ${ALGO} = "GMCB" )
then
/usr/bin/testSampling  -afficheVecteurisation ${WIDTH} CENTER     -afficheContourXFIG 0 0 -enteteXFIG -estim${ALGO} ${WIDTH} -afficheImage imageFond.png ${SIZE} -savePolygon FichiersTmp/sampledContour.dat < FichiersTmp/contour.sdp  > FichiersTmp/tmp.fig 2> FichiersTmp/log.txt
CONTOUR_SAMPLED=FichiersTmp/sampledContour.dat;
fi


if( test ${ERROR}  == "COMPUTE" )
then 
  /usr/local/bin/testErrorMeasure -polygonA ${CONTOUR_SAMPLED} 0 1  -polygonB FichiersTmp/contour.sdp 0 1 2> FichiersTmp/logErrorHausdorff.txt;
fi


fig2dev -L eps FichiersTmp/tmp.fig  FichiersTmp/tmp.eps  2> FichiersTmp/log3.txt;
if  ( test ${ALGO} = "BCCA" -o ${ALGO} = "GMCB" )
then
echo "Curvature Based Contour Reconstruction (${ALGO}) E=${WIDTH} <BR>" > FichiersTmp/info.txt  ;
cat FichiersTmp/log.txt |grep "of segments" >> FichiersTmp/info.txt; 
echo "<BR> " >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "of arcs" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Curvature BCCA" >> FichiersTmp/info.txt; 
cat FichiersTmp/log.txt |grep "Curvature GMC" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Segmentation time:" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Execution time:" >> FichiersTmp/info.txt; 
fi
if  ( test ${ALGO} = "NASR" )
then
echo "Nguyen Arcs Segment  Reconstruction (${ALGO}) E=${WIDTH} <BR>" > FichiersTmp/info.txt  ;
cat FichiersTmp/log.txt |grep "of segments" >> FichiersTmp/info.txt; 
echo "<BR> " >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "of arcs" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Curvature GMCB" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Segmentation time:" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Execution time:" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Nb points" >> FichiersTmp/info.txt; 
fi
if  ( test ${ALGO} = "VC"  )
then

echo "Resulting polygon: <a href="FichiersTmp/polygonVC.dat"> polygonVC.dat</a> <BR>  " > FichiersTmp/info.txt;
echo "Visual Curvature Reconstruction Scale= ${WIDTH} <BR>" >> FichiersTmp/info.txt  ;
echo "Nb contour points: ${NB_POINTS} <BR>" >> FichiersTmp/info.txt  ;

cat FichiersTmp/log.txt | grep "Visual curvature precomputation" >> FichiersTmp/info.txt;
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt | grep "Multi-scale visual curvature" >> FichiersTmp/info.txt;



fi

if( test ${ERROR}  == "COMPUTE" )
then 
      ERR=$(cat FichiersTmp/logErrorHausdorff.txt | grep "Hausdorff error" | cut -d " " -f 8); 
    echo "<BR> Hausdorff error: ${ERR} " >> FichiersTmp/info.txt ;
  
fi


# Sauvegarde des fichiers sources dans l'archive
#cp ${NAME} FichiersTmp/contourSRC.fc;
#/usr/local/bin/freeman2pgm -d 2 -auto_center   < FichiersTmp/contourSRC.fc  > FichiersTmp/contourSRC.pgm 
#convert FichiersTmp/contourSRC.pgm FichiersTmp/contourSRC.gif;


epstopdf  FichiersTmp/tmp.eps;
pdftoppm FichiersTmp/tmp.pdf FichiersTmp/tmp.ppm ;
convert FichiersTmp/tmp.ppm-1.ppm FichiersTmp/tmp.gif;









