#include<list>
#include<SolvePolytope.hpp>
#include<Droite.hpp>
#include<iostream>

//Constructeur par d�faut
SolvePolytope::SolvePolytope(){
	LI.clear(); LD.clear();
	dalpha=NULL; dbeta=NULL;
	estInfini=true;
	demiplanpositif=0;
}

//constructeur o� le signe de 'a' d�finit le demi plan dans lequel on travaille
SolvePolytope::SolvePolytope(int a){ 
	LI.clear(); LD.clear();
	dalpha=NULL; dbeta=NULL;
	estInfini=true;
	demiplanpositif=a; 
	if (a>0) {
		Droite madroite(1,0,0);
		ajouterDroite(madroite);
	} else {
		//on choisit le demi espace positif => il faudra inverser les x des contraintes!
		Droite madroite(1,0,0);
		ajouterDroite(madroite);
	}
}

//Destructeur
SolvePolytope::~SolvePolytope(){}

//Accesseurs
bool SolvePolytope::getEstInfini() { return estInfini; }
std::list<Droite> SolvePolytope::getLD() { return LD; }
std::list<Intersection> SolvePolytope::getLI() { return LI; }


/***************************************************************/
/* algorithme it�ratif qui met � jour le polytope � l'ajout d'une nouvelle contrainte (droite)
 * Il retourne VRAI s'il existe encore des solutions apr�s l'ajout de la contrainte
***************************************************************/
bool SolvePolytope::ajouterDroite(Droite d){
	//sauvegarde du polytope au cas ou la contrainte ne pourrait pas �tre ajout�e
	std::list<Droite> LDsave = LD ;
	std::list<Intersection> LIsave = LI ;
	bool solutionExiste=true;
	bool contraintePossible=true;

	/***************************************************************/
	/* INITIALISATION */
	//premi�re droite
	if (LD.empty()) { LD.push_back(d); dalpha=&(LD.back()); } 
	//deuxi�me droite
	else if (LD.size() == 1) {
		LD.push_back(d);
		dbeta=&(LD.back());
		Intersection inter(&(LD.front()),&(LD.back()));
		LD.front().setInfo(1); LD.back().setInfo(1);
		LI.push_back(inter);
	}
	//� ce stade, on a deux droites d�finissant un polytope infini a deux c�t�s. les deux droites dalpha et dbeta sont marqu�es 1 fois

	/***************************************************************/
	/* PREMIER ETAT: LE POLYTOPE EST INFINI*/
	else if (estInfini) {
		LD.push_back(d);
		//ETAPE 1: On regarde si la nouvelle contrainte (n'exclue pas)/(ne passe pas par) certaines intersections 
		std::list<Intersection>::iterator LI_it=LI.begin();
		while (LI_it != LI.end() ) {
			//lorsque une intersection est exclue
			if ( ! ( d.verifie((*LI_it).getX(),(*LI_it).getY()) ) ) {
				//on met � jour les marqueurs des droites s'intersectant, et on supprime l'intersection
				(*LI_it).getD1().decrInfo(); (*LI_it).getD2().decrInfo();
				LI_it=LI.erase(LI_it); LI_it--;
			}
			//si on passe par une intersection !! RISQUE D'ERREUR DE CALCUL !
			else if ( d.passePar((*LI_it).getX(),(*LI_it).getY()) ) {
				//trois droites se coupent sur un sommet du polytope solution, on choisit parmis les trois celle qu'on supprime
				switch (choixParmisTrois((*LI_it).getD1(),(*LI_it).getD2(),LD.back())) {
					//contraintes insatisfiables: pas de solutions, on peut quitter
					case 0: solutionExiste=false; break;
					//dans tous les autres cas, on remplace la contrainte redondante par la nouvelle droite
					case 3: LD.pop_back();
					    	LI_it=LI.end(); LI_it--;
						contraintePossible=false; break;
					case 1: (*LI_it).getD2().decrInfo();
					    	LD.remove((*LI_it).getD1());
						(*LI_it).setD1(&LD.back());
						//LD.back().incrInfo();
					    	LI_it=LI.erase(LI_it); LI_it--; break;
					case 2: (*LI_it).getD1().decrInfo();
					    	LD.remove((*LI_it).getD2()); 
						(*LI_it).setD2(&LD.back());
						//LD.back().incrInfo();
					    	LI_it=LI.erase(LI_it); LI_it--;	break;
				}
			}
			LI_it++;
		}
		//ETAPE 2: on regarde si les intersections de la nouvelle contraintes v�rifient toutes les autres
		std::list<Droite>::iterator LD_it=LD.begin();
		while ( (contraintePossible) && (solutionExiste) && (*LD_it != LD.back()) && (LD_it != LD.end()) ) {
			//Cas particulier, les droites sont paralleles
			if (LD.back().estParallele(*LD_it)) {
				//on ne fait rien, cela pose-t-il probleme ?!? ?!?
			}
			//On calcule l'intersection des deux contraintes
			else{
				Intersection inter(&(*LD_it),&(LD.back()));
				std::list<Droite>::iterator LD_itemp=LD.begin();
				bool aGarder=true;
				//on la confronte a toutes les autres
				while ( (*LD_itemp != LD.back()) && (LD_itemp != LD.end()) && aGarder ) {
					if (!(*LD_itemp).verifie(inter.getX(),inter.getY())) {
						aGarder=false;	
					}
					LD_itemp++;
				}
				//si elle v�rifie toutes les contraintes, on la garde
				if (aGarder) {
					inter.getD1().incrInfo(); inter.getD2().incrInfo();
					LI.push_back(inter);
				}
			}
			LD_it++;
		}
		//ETAPE 3: Interpr�tation des donn�es et formatage
		//d�termination de dalpha (est il le meme ou pas)
		switch((*dalpha).getInfo()) {
			case 0: if (LD.back().getInfo()==1) { 
					dalpha=&(LD.back()); // d devient dalpha
				} else { } break;
			case 2:	if (LD.back().getInfo()==1) { 
					dalpha=&(LD.back()); // d devient dalpha
				} else { } break;
			default: break;
		}
		//d�termination de dbeta (idem)
		switch((*dbeta).getInfo()) {
			case 0:	if (LD.back().getInfo()==1) {
					dbeta=&(LD.back()); //d devient dbeta
				} else { } break;
			case 2:	if (LD.back().getInfo()==1) {
					dbeta=&(LD.back()); //d devient dbeta
				} else { } break;
			default: break;
		}
		LD_it=LD.begin();
		int cpt=0; int i=1;

		//on efface les contraintes redondantes en comptant le nombre de c�t�s infini
		while ( (solutionExiste) && (LD_it != LD.end()) ) {
			switch( (*LD_it).getInfo() ) {
				case 0: LD_it=LD.erase(LD_it); LD_it--; break; //contrainte supprim�e!
				case 1:	cpt++; break; // est soit dalpha soit dbeta (c�t� infini du polytope)
				case 2: break; //contrainte born�e par deux sommets
				default: LD_it=LD.erase(LD_it); LD_it--; //std::cout << "!! ERREUR MARQUAGE CONTRAINTE!\n "; break;
			}
			LD_it++; i++;
		}
		switch (cpt) {
			case 0: estInfini=false; break; //aucune contrainte infini: LE POLYTOPE EST FINI !
			case 1: /*std::cout << "!! ERREUR un seul c�t� infini ?!?\n";*/ break;
			case 2: break;
			default: /*std::cout << "!! ERREUR trop de c�t�s infini!\n";*/ break;
		}
	}

	/***************************************************************/
	/* SECOND ETAT: LE POLYTOPE EST FINI */
	else {
		LD.push_back(d);
		//ETAPE 1: On regarde si la nouvelle contrainte n'exclue pas certaines intersections
		std::list<Intersection>::iterator LI_it=LI.begin();
		while (LI_it != LI.end() ) {
			//lorsque une intersection est exclue
			if ( ! ( d.verifie((*LI_it).getX(),(*LI_it).getY()) ) ) {
				//on met � jour les marqueurs des droites s'intersectant, et on supprime l'intersection
				(*LI_it).getD1().decrInfo(); (*LI_it).getD2().decrInfo();
				LI_it=LI.erase(LI_it); LI_it--;
				//std::cout << "          => on retire le sommet: ( " << (*LI_it).getX() << " , " << (*LI_it).getY() << " ) \n";

			}
/*
			//si on passe par une intersection
			else if ( d.passePar((*LI_it).getX(),(*LI_it).getY()) ) {
				//std::cout << "         * La droite passe par un sommet existant! choix de la droite!\n";
				switch (choixParmisTrois((*LI_it).getD1(),(*LI_it).getD2(),LD.back())) {
					case 0: solutionExiste=false; break;
					case 3: LD.pop_back(); 
						//std::cout << "elimination de 3\n";
						LI_it=LI.end(); LI_it--;
						contraintePossible=false;
					break;
					case 1: (*LI_it).getD2().decrInfo();(*LI_it).getD1().decrInfo();
						//std::cout << "elimination de 1\n";
					    	LD.remove((*LI_it).getD1());
					    	LI_it=LI.erase(LI_it); LI_it--;
					break;
					case 2: (*LI_it).getD2().decrInfo();(*LI_it).getD1().decrInfo();
						//std::cout << "elimination de 2\n";
					    	LD.remove((*LI_it).getD2());
					    	LI_it=LI.erase(LI_it); LI_it--;
					break;
				}
			}
*/
			LI_it++;
		}
		//Si le polytope �tait fini et qu'il ne reste aucun sommet dans la liste: pas de solutio!
		if (LI.size()==0) { solutionExiste=false; }

		//ETAPE 2: On intersecte la nouvelle contrainte avec les contraintes marqu�es une fois (info==1)
		std::list<Droite>::iterator LD_it=LD.begin();
		while ( (*LD_it != LD.back()) && (LD_it != LD.end()) ) {
			if (LD.back().estParallele(*LD_it)) {
				//std::cout << "          * gestion de droites paralleles \n";
			}
			else if ((*LD_it).getInfo()==1) {
				Intersection inter(&(*LD_it),&(LD.back()));
				(*LD_it).incrInfo(); LD.back().incrInfo();
				LI.push_back(inter);
			}
			LD_it++;
		}
		//ETAPE 3: Interpr�tation des donn�es et formatage
		LD_it=LD.begin();
		int cpt=0;
		//on efface les contraintes redondantes en comptant le nombre de c�t�s infini
		while ( (solutionExiste) && (LD_it != LD.end()) ) {
			switch( (*LD_it).getInfo() ) {
				case 0: LD_it=LD.erase(LD_it); LD_it--; break;
				case 1:	cpt++; break;
				default: break;
			}
			LD_it++;
		}
		switch (cpt) {
			case 0: break;
			//default: std::cout << "!!!!!!!!!! perte de la cloture du polytope!\n"; break;
		}
	}
	/***************************************************************/
	/* INTERPRETATION DES DONNEES */
	if (solutionExiste) return true; //retourne vrai si la nouvelle contrainte est coh�rente
	else { LD=LDsave; LI=LIsave; return false; } //retourne faux si le polytope est nul
}

/***************************************************************/
/***************************************************************/
/***************************************************************/

//retourne 1 (respectivement 2 ou 3) suivant si la contrainte a �liminer est la 1 (respectivement 2 ou 3)
int SolvePolytope::choixParmisTrois(Droite C1, Droite C2, Droite C3) {
	Droite *d1,*d2,*d3;
	//tri des trois droites par ordre de pent� d�croissante
	//si une droite est verticale, elle est de pente maximum (car infinie)
	if (C1.getB()==0) {
	       	d1=&C1; (*d1).setInfo(1);
		if ( C2.getA()/C2.getB() < C3.getA()/C3.getB() ) { d2=&C2; (*d2).setInfo(2); d3=&C3; (*d3).setInfo(3); }
		else { d2=&C3; (*d2).setInfo(3); d3=&C2; (*d3).setInfo(2); }
	}
	else if (C2.getB()==0) { d1=&C2; (*d1).setInfo(2);
		if ( C1.getA()/C1.getB() < C3.getA()/C3.getB() ) { d2=&C1; (*d2).setInfo(1); d3=&C3; (*d3).setInfo(3); } 
		else { d2=&C3; (*d2).setInfo(3); d3=&C1; (*d3).setInfo(1); }	
	} 
	else if (C3.getB()==0) { d1=&C3; (*d1).setInfo(3);
		if ( C2.getA()/C2.getB() < C1.getA()/C1.getB() ) { d2=&C2; (*d2).setInfo(2); d3=&C1; (*d3).setInfo(1); } 
		else { d2=&C1; (*d2).setInfo(1); d3=&C2; (*d3).setInfo(2); }	
	}
	//aucune droite n'est verticale
	else if ( C1.getA()/C1.getB() < C2.getA()/C2.getB() ) {
		if ( C1.getA()/C1.getB() < C3.getA()/C3.getB() ) { d1=&C1; (*d1).setInfo(1);
			if ( C2.getA()/C2.getB() < C3.getA()/C3.getB() ) { d2=&C2; (*d2).setInfo(2); d3=&C3;(*d3).setInfo(3); }
			else { d2=&C3; (*d2).setInfo(3); d3=&C2; (*d3).setInfo(2); }	
		}
		else { d1=&C3; (*d1).setInfo(3); d2=&C1; (*d2).setInfo(1); d3=&C2; (*d3).setInfo(2); }
	}
	else {
		if ( C2.getA()/C2.getB() < C3.getA()/C3.getB() ) { d1=&C2; (*d1).setInfo(2);
			if ( C1.getA()/C1.getB() < C3.getA()/C3.getB() ) { d2=&C1; (*d2).setInfo(1); d3=&C3; (*d3).setInfo(3); }
			else { d2=&C3; (*d2).setInfo(3); d3=&C1; (*d3).setInfo(1); }	
		}
		else { d1=&C3; (*d1).setInfo(3); d2=&C2; (*d2).setInfo(2); d3=&C1; (*d3).setInfo(2); }
	}
	
	//en fonction des signes des 'B' on choisit la contrainte a �liminer
	bool b1=( ( ((*d1).getB()==0) && ((*d1).getA()<0)) || ((*d1).getB() > 0) ); 
	bool b2=( ( ((*d2).getB()==0) && ((*d2).getA()<0)) || ((*d2).getB() > 0) ); 
	bool b3=( ( ((*d3).getB()==0) && ((*d3).getA()<0)) || ((*d3).getB() > 0) ); 

		// si '000' ou '111' on �limine 2
		if ((b1 && b2 && b3) || (!b1 && !b2 && !b3)) { return (*d2).getInfo(); }
		// si '100' ou '011' on �limine 3
		else if (( b1 && !b2 && !b3) || ( !b1 && b2 && b3 ) ) { return (*d3).getInfo(); }
		// si '110' ou '001' on �limine 1
		else if (( b1 && b2 && !b3 ) || ( !b1 && !b2 && b3) ) { return (*d1).getInfo(); }
		//sinon, les solutions sont r�duites � un point
		else return 0;
}

/***************************************************************/
/***************************************************************/
//s'assurer avant que les droites soient bien parall�les et NON verticales!
char SolvePolytope::contrainteparallele(Droite C1,Droite C2) {
	bool dir= (C1.getB()*C2.getB()) > 0;
	//on prend un point de C1 et on regardre s'il v�rifie C2
	double y1=C1.getVal(0.0);
	bool p1=C2.verifie(0.0,y1);
	//on prend un point de C2 et on regardre s'il v�rifie C1
	double y2=C2.getVal(0.0);
	bool p2=C1.verifie(0.0,y2);
	//on conclue
	if (p1 && p2) {
		if (dir) return '='; //les droites sont identiques
		else return 'B'; //l'union des contraintes d�finit une bande
	} 
	else if (p1) return '1'; //la contrainte C2 est v�rifi�e par toute solution de C1
	else if (p2) return '2'; //la contrainte C1 est v�rifi�e par toute solution de C2
	else return '!'; // CONTRAINTES INCOMPATIBLES !
}


/***************************************************************/
/***************************************************************/
//ajoute le pixel pix, c'est � dire deux contraintes pour le polytope actuel!

bool SolvePolytope::ajouterPixel(Pixel pix) {

/* */std::list<Droite> LDsave = LD ;
/* */std::list<Intersection> LIsave = LI ;
	bool reponse=true; Droite madroite; double a,b,c;

	//DANS LA POLYTOPE DU DEMI ESPACE POSITIF
	if (demiplanpositif>0) {
		//std::cout<<" SP+ > ajout de " << pix.getX() << " " << pix.getY() << " de taille " << pix.getInf() << "\n";
		// - y - (alpha-t/2)*x + (beta+t/2) >= 0   (1)
		a=(double)(redim(pix.getInf()))/2-(double)(pix.getX());
		b=-1.0;
		c=(double)(pix.getY())+(double)(redim(pix.getInf()))/2;
		madroite=Droite(a,b,c);
		//std::cout << "     * -> ajout de la premi�re contrainte: " << a << "x + " << b << "y + " << c << " >=0\n";
		if (ajouterDroite(madroite)) {
			// y + (alpha+t/2)*x - (beta-t/2) >= 0  (4)
			a=(double)(pix.getX())+(double)(redim(pix.getInf()))/2;
			b=1.0;
			c=(double)(redim(pix.getInf()))/2-(double)(pix.getY());
			madroite=Droite(a,b,c);
			//std::cout << "     * -> ajout de la deuxieme contrainte: " << a << "x + " << b << "y + " << c << " >=0\n";
			if (ajouterDroite(madroite)) { /*std::cout << "\n---> PIXEL AJOUTE!        taille= " << pix.getInf();*/ }
			else reponse=false;
		} else reponse=false;

	//DANS LA POLYTOPE DU DEMI ESPACE NEGATIF
	} else if (demiplanpositif<0) {
	//std::cout<<" SP- > ajout de " << pix.getX() << " " << pix.getY() << " de taille " << pix.getInf() << "\n";
		// - y - (alpha+t/2)*x + (beta+t/2) >= 0   (2)
		a=-((double)(pix.getX())+(double)(redim(pix.getInf()))/2);
		b=-1.0;
		c=(double)(pix.getY())+(double)(redim(pix.getInf()))/2;
		madroite=Droite(-a,b,c);
		//std::cout << "     * -> ajout de la premi�re contrainte: " << a << "x + " << b << "y + " << c << " >=0\n";
		if (ajouterDroite(madroite)) {
			// y + (alpha-t/2)*x + (t/2-beta) >= 0   (3)
			a=(double)(pix.getX())-(double)(redim(pix.getInf()))/2;
			b=1.0;
			c=(double)(redim(pix.getInf()))/2-(double)(pix.getY());
			madroite=Droite(-a,b,c);
			//std::cout << "     * -> ajout de la deuxieme contrainte: " << a << "x + " << b << "y + " << c << " >=0\n";
			if (ajouterDroite(madroite)) {  }
			else reponse=false;
		} else reponse=false;
	} else { /* std::cout << "\n SOLVE POLYTOPE MAL INITIALIS� \n";*/ }

	if (LD.size()==0) { reponse=false; }
	if (!reponse) {	LD=LDsave; LI=LIsave; }
	return reponse;
}

double SolvePolytope::redim(int mstl){
	return (double)mstl;
}
