<?php
 system("/home/kerautre/Sites/CBContours/Scripts/generateArchivePage.sh"); 
?>