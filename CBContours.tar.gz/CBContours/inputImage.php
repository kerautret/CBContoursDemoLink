




<hr color=#330090  align=left > 

<BR>

<form method="post" enctype="multipart/form-data" action="index.php">
<TABLE width=10% >
<TR>
<TD height=10% > <img src="ImagesExamples/imageTest1.gif" height=90px >  </TD>
<TD width=10% > <img src="ImagesExamples/imageTest2.gif" height=90px >  </TD>
<TD width=10% > <img src="ImagesExamples/photoFleur.gif" height=90px >  </TD>
</TR>
<TR>
<td align=center>  <input type="radio" name="sampleNum" value="1" > </td>
<td align=center> <input type="radio" name="sampleNum" value="2"  > </td>
<td align=center> <input type="radio" name="sampleNum" value="3"  > </td>
</TR>
</TABLE>



<input type="hidden" name="inputImagePosted" value="ok">
<input type="hidden" name="inputContourPosted" value="non">

<div id = "fileSelect" >
   Select image file: <br>
   <INPUT type=hidden name=MAX_FILE_SIZE  VALUE=2000000>
 <input type="file" name="fichierImage" size="20">  
   <input type="radio" name="public" value="pubOK" > Leave image in the <a href="PublicArchives/pageArchive.php"> public domain </a> 
</div>



<BR>
  Contour extraction thresold <input type="text" name ="thresold" value="128" size="3" > min Size <input type="text" name ="minSize" value="300" size="3" > <BR>

   <input type="radio" name="option" value="advanced">  option:  
   x <input type="text" name ="x" value="0" size="3" > 
   y <input type="text" name ="y" value="0" size="3" > 
   maxDistance <input type="text" name ="distance" value="0" size="3" > 
   <BR>

<br>
<select name="algo" onchange="">
   <option value="GMCB">Curvature Based Reconstruction (GMC) [1] </option>
   <option value="BCCA">Curvature Based Reconstruction (BCCA) [2] </option>
   <option value="NASR">Nguyen Arcs/Segments Reconstruction (NASR) [3] </option>
   <option value="VC">Visual Curvature (VC) [4]</option>
</select>
   width:
<select name="width" onchange="">
<option value="1">1</option>
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="30">30</option>
<option value="40">40</option>

</select>


<BR>
   Compute Hausdorff error (complexity O(N2)) <input type="radio" name="hausdorff" value="compError">
<BR>

<input type="submit" name="computeBoxes" value="Compute representation">
   

</form>

<hr color=#330090  width=800px align=left > 
