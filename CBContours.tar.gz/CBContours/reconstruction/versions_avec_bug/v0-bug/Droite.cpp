#include <Droite.hpp>
#include <iostream>

//constructeurs
Droite::Droite() {
	a=0.0; b=0.0; c=0.0; info=0;
}

Droite::Droite(const Droite & e) {
	a=e.getA();
	b=e.getB();
	c=e.getC();
	info=e.getInfo();
}

Droite::Droite(double aa,double bb,double cc){
	a=aa; b=bb; c=cc; info=0;
}

//destructeur
Droite::~Droite() {}

//accesseurs
double Droite::getA() const { return a; }
double Droite::getB() const { return b; }
double Droite::getC() const { return c; }
int Droite::getInfo() const {return info; }

//retourne true si le point (x,y) appartient au demi plan aX+bY+c>=0
bool Droite::verifie(double xx,double yy){
	return ((a*xx+b*yy+c) >= 0);
}

//retourne true si le point (x,y) appartient au demi plan aX+bY+c>=0
bool Droite::passePar(double xx,double yy){
	return ((a*xx+b*yy+c) == 0);
}

//s'assurer que la droite ne soit pas verticale (b!=0)
double Droite::getVal(double abs) { 
	return (((-a)*abs-c)/b);
}

//retourne true si les droites sont paralleles
bool Droite::estParallele(Droite d) {
	if (b==0) {
		return (d.getB()==0);
	}
	else {
		return ((a/b) == (d.getA()/d.getB()));
	}
}

//modifieur
void Droite::setInfo(int i) { info=i; }
void Droite::incrInfo() { info++; }
void Droite::decrInfo() { info--; }

//operateurs
Droite& Droite::operator=(const Droite &source){ c=source.getC(); a=source.getA(); b=source.getB(); info=source.getInfo(); return *this;}

bool Droite::operator!=(const Droite &source){
	return ! ( ( (a/source.getA()) == (b/source.getB()) )  && 
		( (a/source.getA()) == (c/source.getC()) )    ); }

//ne retourne vrai que si c'est le MEME OBJET!! (meme adresse m�moire)
bool Droite::operator==(const Droite &source){
	return &source == this;
//	return ( ( (a/source.getA()) == (b/source.getB()) )   	&& 
//		( (a/source.getA()) == (c/source.getC()) )    ); }
}
