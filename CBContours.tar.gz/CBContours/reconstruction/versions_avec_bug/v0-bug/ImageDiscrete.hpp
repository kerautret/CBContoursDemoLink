#ifndef IMAGEDISCRETE_H
#define IMAGEDISCRETE_H

#include <cmath>
#include <list>
#include<map>
#include<Pixel.hpp>

//pour lire le fichier lapin
#include <string>
#include <iostream>
#include <fstream>
//r�cup�rer les trois entiers d'une ligne
#include <sstream>

//struct foncteur{ bool operator()(const int a, const int b) const { return a < b; } };

class ImageDiscrete {

	//Membres de la classe
	std::list<Pixel> listepixels;
	int xmax, ymax;
	int seuil; //sur la longueur des tangentes 
	double fact; //facteur de grossissement de pixels

	public:
	//Constructeurs
	ImageDiscrete();
	ImageDiscrete(int,double);

	//Destructeur
	~ImageDiscrete();

	//Accesseurs
	int getDim();
	std::list<Pixel>& getList();

	//Charge la courbe depuis le fichier
	void loadPic();

	//Etiquette chaqu'un des pixels
	void createLabel();

	private:
	//retourne vrai si la suite de pixel entre les it�rateurs est un segment discret
	bool estUnSegment(std::list<Pixel>::iterator,std::list<Pixel>::iterator);

	//incr�mente/d�cr�mente l'it�rateur tel qu'il boucle sur la liste
	void suivant(std::list<Pixel>::iterator&);
	void precedant(std::list<Pixel>::iterator&);

	//donne la direction de freeman entre les deux pixels
	int codefree(Pixel,Pixel); 

};

#endif 

