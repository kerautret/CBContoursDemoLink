<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


<?php include("cpt.php") ?>





   <h2> Curvature Based Contour representation demo</h2>
   <a align=left color=white  href=" PublicArchives/pageArchive.php" > archive page </a>
<br>







<DIV id="saisie">
<h4> Choose a test contour </h4>
<?php include("inputContour.php") ?>



<h4>or upload an image and  select a contour threshold  </h4> 
<?php include("inputImage.php") ?>


<tr id="Kerautret2009" class="entry">
   <td> [1] Kerautret, B. &amp; Lachaud, J.-O. (2009), <i>"Curvature Estimation along Noisy Digital Contours by Approximate Global Optimization"</i>. Pattern Recognition, October 2009. Volume 42(10), pp. 2265-2278.
  <a href="http://www.loria.fr/~kerautre">[homepage]</a><br><br>
	</td>
</tr>

	<td>[2] Malgouyres, R., Brunet, F. &amp; Fourey, S. (2008), <i>"Binomial Convolutions and Derivatives Estimations from Noisy Discretizations"</i>, In Proceedings of the Int Conf on DGCI. april 2008. Volume 4992, pp. 370-379. Springer.
<br><br>
	</td>

<tr id="Nguyen2010b" class="entry">
	<td>[3] Nguyen, T.P. (2010), <i>"Etude des courbes discr�tes: applications en analyse d'images"</i>.
						   Phd Thesis, <a href="http://www.loria.fr/~nguyentp">[homepage]</a><br><br>
	</td>
</tr>


<tr id="Liu2008" class="entry">
						   <td> [4] Liu, H., Latecki, L.J. &amp; Liu, W. (2008), <i>"A Unified Curvature Definition for Regular, Polygonal, and Digital Planar Curves"</i>. Int. J. Comput. Vision, Volume 80(1), pp. 104-124. Kluwer Academic Publishers.
  <br><br>
	</td>
</tr>





</DIV>



<DIV id="resultats">
			

<?php  


$pubDomain = $_POST['public'];


if("$_POST[inputContourPosted]"=="ok"){
    
  $tabSelectCONTOUR = array("1" => "/home/kerautre/Sites/CBContours/ImagesExamples/cheval.sdp",
			"2" => "/home/kerautre/Sites/CBContours/ImagesExamples/klokan.sdp",
			"3" => "/home/kerautre/Sites/CBContours/ImagesExamples/castle.sdp",
			"4" => "/home/kerautre/Sites/CBContours/ImagesExamples/female.sdp",
			"5" => "/home/kerautre/Sites/CBContours/ImagesExamples/spirale2.sdp");
 
  $tabSelectImageSRC = array("1" => "/home/kerautre/Sites/CBContours/ImagesExamples/cheval.sdp",
			"2" => "/home/kerautre/Sites/CBContours/ImagesExamples/klokan.sdp",
			"3" => "/home/kerautre/Sites/CBContours/ImagesExamples/castle.sdp",
			"4" => "/home/kerautre/Sites/CBContours/ImagesExamples/female.sdp",
			"5" => "/home/kerautre/Sites/CBContours/ImagesExamples/spirale2.sdp");


  $tabSelectImageBG = array("1" => "/home/kerautre/Sites/CBContours/ImagesExamples/chevalBG.png",
			    "2" => "/home/kerautre/Sites/CBContours/ImagesExamples/klokanBG.png",
			    "3" => "/home/kerautre/Sites/CBContours/ImagesExamples/castleBG.png",
			    "4" => "/home/kerautre/Sites/CBContours/ImagesExamples/femaleBG.png",
			    "5" => "/home/kerautre/Sites/CBContours/ImagesExamples/femaleBG.png");



 $PathCONTOUR=$tabSelectCONTOUR[$_POST['sampleNum']];
 $PathImageSRC=$tabSelectImageSRC[$_POST['sampleNum']];
 $PathImageBG=$tabSelectImageBG[$_POST['sampleNum']];
 $width=$_POST['width'];

 $error=($_POST['hausdorff']=='compError');
 if($error)
   $error="error";
 else
   $error="";


if($_POST[algo]=="CBR"){  
    exec("/home/kerautre/Sites/CBContours/Scripts/runCBContours.sh $PathCONTOUR $PathImageBG $width $error  ");      

} 
if($_POST[algo]=="BCC"){  

 exec("/home/kerautre/Sites/CBContours/Scripts/runCBContoursBCC.sh $PathCONTOUR $PathImageBG $width $error   ");      
} 
if($_POST[algo]=="NAR"){  
  exec("/home/kerautre/Sites/CBContours/Scripts/runNARContours.sh $PathCONTOUR $PathImageBG $width $error  ");      

} 
if($_POST[algo]=="VC"){  
 $width=$width/100.0;
 exec("/home/kerautre/Sites/CBContours/Scripts/runCBContourVC.sh $PathCONTOUR $PathImageBG $width $error   ");      
} 




echo('<BR><BR> <img  width=256px src="FichiersTmp/tmp.gif" >');
echo('<BR>');
echo('<a href="FichiersTmp/tmp.pdf"> result.pdf </a>');
echo('<BR>');
system('cat /home/kerautre/Sites/CBContours/FichiersTmp/info.txt ');
echo('<BR>');


if($pubDomain == "pubOK"){
system("/home/kerautre/Sites/CBContours/Scripts/addToArchives.sh");
system("/home/kerautre/Sites/CBContours/Scripts/generateArchivePage.sh");
}
}    
elseif(("$_POST[inputImagePosted]"=="ok") and  (is_numeric($_POST['thresold']))and  (is_numeric($_POST['minSize']))){
      
  system("echo 'ooooooooo'> FichiersTmp/titi.txt");




$tabSelectImage = array("1" => "/home/kerautre/Sites/CBContours/ImagesExamples/imageTest1.gif",
			"2" => "/home/kerautre/Sites/CBContours/ImagesExamples/imageTest2.gif",
			"3" => "/home/kerautre/Sites/CBContours/ImagesExamples/photoFleur.gif");





$tmp_file = $_FILES['fichierImage']['tmp_name'];


$size=$_FILES['fichierImage']['size'];
if($_FILES['fichierImage']['error']==2 || $size >1000000 ){
  exit("File size exceeds maximal size: $size  (max=2Mo) "); 
		    }


if($_FILES['fichierImage']['error']==2){
  exit("Fichier de taille trop grande (max=2Mo) "); 
}


if( !is_uploaded_file($tmp_file) ){  
  $num=$_POST['sampleNum'];
if($num=="")
  $num="1";

$PathImage=$tabSelectImage[$num];
  system("convert $PathImage FichiersTmp/imageContour.pgm"); 
}else{
  $type_file = $_FILES['fichierImage']['type'];
  $typeExt = $_FILES['fichierImage']['ext'];

  if( preg_match('#[\x00-\x1F\x7F-\x9F/\\\\]#', $name_file)){   	
    exit("Nom de fichier non valide");
}			

  
  $allowed_types = array("image/pjpeg" => ".jpeg",
		       "image/jpeg" => ".jpeg",
			 "image/gif" => ".gif",
			 "x-png" => ".png",
			 "image/x-portable-graymap" => ".pgm");
  
  
  foreach ($allowed_types as $nameType => $extension){
    if( $type_file == $nameType ){
      $nameToConvert = "fileUploaded"."$extension";
      move_uploaded_file($tmp_file, "FichiersTmp/$nameToConvert");
      system("convert FichiersTmp/$nameToConvert FichiersTmp/imageContour.pgm"); 
    }  
  }
  
}



$th=$_POST['thresold'];
$minSize = $_POST['minSize'];
$pubDomain = $_POST['public'];

 $width=$_POST['width'];

$x=$_POST['x'];
$y=$_POST['y'];
$distance=$_POST['distance'];
$advanced=$_POST['option'];
$algo=$_POST['algo'];
if($algo == "VC"){
  $width=$width/100;
}
$error=($_POST['hausdorff']=='compError');
 if($error)
   $error="COMPUTE";
 else
   $error="NO_COMPUTE";

if($advanced=="advanced"){    
     system("/home/kerautre/Sites/CBContours/Scripts/runCBContoursImage.sh $error  /home/kerautre/Sites/CBContours/FichiersTmp/imageContour.pgm $th $minSize $width $algo $x $y $distance");

  }else{
    system("/home/kerautre/Sites/CBContours/Scripts/runCBContoursImage.sh  $error /home/kerautre/Sites/CBContours/FichiersTmp/imageContour.pgm $th $minSize $width $algo  ");
  }





echo('<BR> <BR> <img  width=256px src="FichiersTmp/tmp.gif" >');
echo('<BR>');
echo('<a href="FichiersTmp/tmp.pdf"> result.pdf </a>');
echo('<BR>');

system('cat /home/kerautre/Sites/CBContours/FichiersTmp/info.txt ');

if($pubDomain == "pubOK"){
  system("/home/kerautre/Sites/CBContours/Scripts/addToArchives.sh");
  system("/home/kerautre/Sites/CBContours/Scripts/generateArchivePage.sh");
}

}





?>


</DIV>

	</DIV>	

	
	</BODY>
</HTML>
