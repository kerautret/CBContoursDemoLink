#!/bin/sh




NAME=$1
NAMEBG=$2
WIDTH=$3



PATH_BASE=/home/kerautre/Sites/CBContours  ;


cd ${PATH_BASE};

export LD_LIBRARY_PATH=/usr/local/lib/;


/usr/local/bin/sdp2freeman < ${NAME} > /tmp/tmp.fc;
/usr/local/bin/curvature_visualc -scale ${WIDTH} < /tmp/tmp.fc 2> FichiersTmp/log.txt  | grep -v '#' | awk '{ if ($4 != 0) printf("%d %d \n", $6, $7); }'>  FichiersTmp/polygonVC.dat ;


if( test $# -eq 4 )
then 
  /usr/local/bin/testErrorMeasure -polygonA FichiersTmp/polygonVC.dat 0 1  -polygonB ${NAME} 0 1 2> FichiersTmp/logErrorHausdorff.txt;
fi


/usr/local/bin/polygone2fig -enteteXFIG < FichiersTmp/polygonVC.dat -drawPolygon 1 2 0 1 -drawVertex 4 2 > FichiersTmp/tmp.fig; 
NB_POINTS=$(wc -l < FichiersTmp/polygonVC.dat );
fig2dev -L eps FichiersTmp/tmp.fig   FichiersTmp/tmp.eps 2> FichiersTmp/logFig.dat



echo "Resulting polygon: <a href="FichiersTmp/polygonVC.dat"> polygonVC.dat</a> <BR>  " > FichiersTmp/info.txt;
echo "Visual Curvature Reconstruction Scale= ${WIDTH} <BR>" >> FichiersTmp/info.txt  ;
echo "Nb contour points: ${NB_POINTS} <BR>" >> FichiersTmp/info.txt  ;

cat FichiersTmp/log.txt | grep "Visual curvature precomputation" >> FichiersTmp/info.txt;
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt | grep "Multi-scale visual curvature" >> FichiersTmp/info.txt;



if( test $# -eq 4 )
then 
ERR=$(cat FichiersTmp/logErrorHausdorff.txt | grep "Hausdorff error" | cut -d " " -f 8); 
echo " Hausdorff error: ${ERR} " >> FichiersTmp/info.txt ;
fi


# Sauvegarde des fichiers sources dans l'archive
cp ${NAME} FichiersTmp/contourSRC.fc;
/usr/local/bin/freeman2pgm -d 2 -auto_center   < FichiersTmp/contourSRC.fc  > FichiersTmp/contourSRC.pgm 
convert FichiersTmp/contourSRC.pgm FichiersTmp/contourSRC.gif;


epstopdf  FichiersTmp/tmp.eps;
pdftoppm FichiersTmp/tmp.pdf FichiersTmp/tmp.ppm ;
convert FichiersTmp/tmp.ppm-1.ppm FichiersTmp/tmp.gif;









