#ifndef DROITE_H
#define DROITE_H

class Droite
{
	//droite de la forme a*x + b*y + c >= 0
	double a; double b; double c;
	int info; //marqueur libre

	public:
	//Constructueurs
	Droite();
	Droite(const Droite&);
	Droite(double,double,double);

	//Destructeur
	~Droite();

	//Accesseurs
	double getA() const;
	double getB() const;
	double getC() const;
	int getInfo() const;

	//Modifieur
	void setInfo(int i);
	void incrInfo();
	void decrInfo();

	//retourne la valeur de y pour un x donn�
	double getVal(double);
	bool passePar(double,double);
	bool verifie(double,double);
	bool estParallele(Droite);

	Droite &operator=(const Droite &source);
	bool operator!=(const Droite &source);
	bool operator==(const Droite &source);
};

#endif

