#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <list>

#include <SolvePolytope.hpp>
#include <Pixel.hpp>
//#include <ImageDiscrete.hpp>
//#include <Droite.hpp>

int main(int nb_args,char** args) {

	std::cout << "\n************************\n** DEBUT DE PROGRAMME **\n************************\n";

	//********************
	//DECLARATION DES VARIABLES LOCALES
	std::list<Pixel> LP; //liste des pixel ORDONNEE du contour
	std::list<Pixel>::iterator LP_it;

	//********************
	//CHARGEMENT DE LA COURBE	
	std::cout << "\n** CHARGEMENT DE LA COURBE (fichier 'noiseLevel.txt') \n";
	std::fstream file("noiseLevel.txt"); //fichier texte (r�sultat de l'estimateur de bruit de Jaco et Bertrand)
	int x,y,taille,trash,cpt=0;
	std::string line;
	while ( getline( file, line ) ) {
		std::istringstream myiss(line);
		myiss >> trash; //information inutile pour la reconstruction
		myiss >> taille; //nouvelle taille de pixel (niveau de bruit)
		myiss >> trash; //information inutile pour la reconstruction
		myiss >> x; myiss >> y; //coordonn�es du pixel
		Pixel p(x,y,taille); //cr�ation du pixel
		LP.push_back(p); //on empile les pixels dans LP (la liste des pixel est ordonn�e)
		cpt++;
	}
	std::cout << "\n** COURBE CHARGEE     TOTAL: " << cpt << " PIXELS \n";

	//********************
	//RECONSTRUCTION
	std::cout << "\n** RECONSTRUCTION DE LA COURBE";
	std::cout << "\n\n->LISTE DES SOMMET: \n";

	LP_it=LP.begin();
	int nbr_sommets=0;

	//� chaque boucle du while, on reconnait un nouveau segment
	while (LP_it != LP.end()) {
		nbr_sommets++;
		//on affiche les coordonn�es du pixels � partir duquel on commence la reconnaissance de segment
		std::cout << (*LP_it).getX() << " " << (*LP_it).getY() << "\n"; 

		//Initialisation des espaces de param�tres (positifs et n�gatifs)
		SolvePolytope spplus(1); 
		SolvePolytope spmoins(-1); 
		bool solplus=true; bool solmoins=true; //vrai tant que les polytopes non nuls

		//� chaque boucle du while, on ajoute un pixel au segment en cours de reconnaissance
		while ((solplus || solmoins) && (LP_it!=LP.end())) {

			//On ajoute les contraintes li�es au pixel dans le demi-plan positif
			if (solplus) {
				if (!spplus.ajouterPixel(*LP_it)) { solplus=false; }
			}

			//On ajoute les contraintes li�es au pixel dans le demi-plan n�gatif
			if (solmoins) {
				if (!spmoins.ajouterPixel(*LP_it)) { solmoins=false; }
			}

			//si les polytopes sont non nuls, on essais d'ajouter le pixel suivant au segment reconnu
			if (solplus || solmoins) { LP_it++; }
			//sinon, on essais de reconnaitre un nouveau segment � partir du pixel pr�c�dent (on sort du premier while)
			else {LP_it--;}
		}
		//segment maximal reconnu, on passe au suivant
	}

	//********************
	std::cout << "->OBJET RECONSTRUIT EN " << nbr_sommets << " SOMMETS\n"; 
	std::cout << "\n************************\n**  FIN DE PROGRAMME  **\n************************\n\n";
	return 0;
}

