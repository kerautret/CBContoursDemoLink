#!/bin/sh

 for pid in $(ps -xa | grep simplification | cut -d " " -f 1) ; do  kill -9 $pid ; done 
 for pid in $(ps -xa | grep cornerdetection | cut -d " " -f 1) ; do  kill -9 $pid ; done 
 for pid in $(ps -xa | grep polygone2fig | cut -d " " -f 1) ; do  kill -9 $pid ; done 




