<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> MS Polygon demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=2; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 10  (ID: Archive_1533291740611)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1533291740611/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1533291740611/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1533291740611/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1533291740611/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1533291740611/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1533291740611/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (GMCB) E=2 <BR> Number of segments: 4 <BR> Number of arcs: 27 <BR> Curvature GMCB time: 224 ms <BR> Segmentation time: 30 ms <BR> Total Execution time: 254 ms <BR> Hausdorff error: 1.9955
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 11  (ID: Archive_0900112911011)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0900112911011/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0900112911011/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0900112911011/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0900112911011/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0900112911011/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0900112911011/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (GMCB) E=2 <BR> Number of segments: 9 <BR> Number of arcs: 208 <BR> Curvature GMCB time: 1125 ms <BR> Segmentation time: 645 ms <BR> Total Execution time: 1770 ms
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 12  (ID: Archive_2032503021011)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2032503021011/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2032503021011/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2032503021011/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2032503021011/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2032503021011/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2032503021011/polygon.txt>polygon.txt</a> <br>  
Resulting polygon: <a href=FichiersTmp/polygonVC.dat> polygonVC.dat</a> <BR> Visual Curvature Reconstruction Scale= 0.02 <BR> Nb contour points: 109 <BR> Visual curvature precomputation in 8 ms. <BR> Multi-scale visual curvature computation in 1154 ms.
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 13  (ID: Archive_1723063041011)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1723063041011/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1723063041011/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1723063041011/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1723063041011/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1723063041011/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1723063041011/polygon.txt>polygon.txt</a> <br>  
Resulting polygon: <a href=FichiersTmp/polygonVC.dat> polygonVC.dat</a> <BR> Visual Curvature Reconstruction Scale= 0.03 <BR> Nb contour points: 295 <BR> Visual curvature precomputation in 16 ms. <BR> Multi-scale visual curvature computation in 3043 ms.
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 14  (ID: Archive_2220253091113)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_2220253091113/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_2220253091113/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_2220253091113/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_2220253091113/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_2220253091113/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_2220253091113/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (GMCB) E=1 <BR> <BR> <BR> <BR> <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 15  (ID: Archive_1426483111113)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1426483111113/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1426483111113/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1426483111113/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1426483111113/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1426483111113/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1426483111113/polygon.txt>polygon.txt</a> <br>  
Resulting polygon: <a href=FichiersTmp/polygonVC.dat> polygonVC.dat</a> <BR> Visual Curvature Reconstruction Scale= 0.02 <BR> Nb contour points: 0 <BR> <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 16  (ID: Archive_1012523181113)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1012523181113/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1012523181113/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1012523181113/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1012523181113/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1012523181113/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1012523181113/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (GMCB) E=1 <BR> <BR> <BR> <BR> <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 17  (ID: Archive_1840362991015)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1840362991015/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1840362991015/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1840362991015/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1840362991015/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1840362991015/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1840362991015/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (BCCA) E=8 <BR> <BR> <BR> <BR> <BR> <BR> Hausdorff error: inf
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 18  (ID: Archive_1732240300116)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1732240300116/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1732240300116/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1732240300116/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1732240300116/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1732240300116/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1732240300116/polygon.txt>polygon.txt</a> <br>  
Nguyen Arcs Segment Reconstruction (NASR) E=3 <BR> <BR> <BR> <BR> <BR> <BR> <BR> Hausdorff error: 0
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 19  (ID: Archive_0925560330216)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0925560330216/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0925560330216/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0925560330216/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0925560330216/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0925560330216/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0925560330216/polygon.txt>polygon.txt</a> <br>  
Nguyen Arcs Segment Reconstruction (NASR) E=2 <BR> <BR> <BR> <BR> <BR> <BR> <BR> Hausdorff error: 0
 </TD></TR>  </TABLE> 
</DIV>
