#ifndef CREERPOLYTOPE_H
#define CREERPOLYTOPE_H

#include <cmath>
#include <list>
#include<Droite.hpp>
#include<Pixel.hpp>

/** classe d�finit le point intersection de deux droites
 */
class Intersection {
	//Membres
	Droite* d1;
	Droite* d2;
	double XX;
	double YY;
	bool existe;
	public:
	//Constructeurs
	Intersection(Droite*,Droite*);
	//Destructeur
	~Intersection();
	//Accesseurs
	Droite& getD1();
	Droite& getD2();
	double getX();
	double getY();
	//Modifier
	void setD1(Droite*);
	void setD2(Droite*);
};


class SolvePolytope {
	
	//Membres de la classe
	std::list<Droite> LD;
	std::list<Intersection> LI;
	bool estInfini;
	Droite* dalpha;
	Droite* dbeta;
	int demiplanpositif;

	public:
	SolvePolytope();
	SolvePolytope(int);
	~SolvePolytope();

	//Accesseurs
	bool getEstInfini();
	std::list<Intersection> getLI();
	std::list<Droite> getLD();

	//algorithme it�ratif qui met � jour le polytope � l'ajout d'une nouvelle contrainte (droite)
	bool ajouterDroite(Droite);

	//ajoute le pixel en argument, c�d deux droites en fonction de demiplanpositif ou pas
	bool ajouterPixel(Pixel);

	int choixParmisTrois(Droite,Droite,Droite);

	char contrainteparallele(Droite,Droite);

	double redim(int);

};

#endif
