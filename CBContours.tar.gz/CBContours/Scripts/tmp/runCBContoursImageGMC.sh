#!/bin/sh






NAME=$1
TH=$2
MINSIZE=$3

WIDTH=$4



PATH_BASE=/home/kerautre/Sites/CBContours  ;


cd ${PATH_BASE};

export LD_LIBRARY_PATH=/usr/local/lib/;


if( test  $# -eq 7 )
then
  /usr/local/bin/pgm2freeman --min $TH --minSize $MINSIZE -i $NAME -selectContour $5 $6 $7 > /home/kerautre/Sites/CBContours/FichiersTmp/contour.fc 2> FichiersTmp/log2.txt; cat FichiersTmp/log2.txt| cut -f 3,4 -d " " > FichiersTmp/size.txt ;
else
    
    /usr/local/bin/pgm2freeman --min $TH --minSize $MINSIZE -i $NAME  > /home/kerautre/Sites/CBContours/FichiersTmp/contour.fc 2> FichiersTmp/log2.txt; cat FichiersTmp/log99.txt| cut -f 3,4 -d " " > FichiersTmp/size.txt ;

fi

/usr/local/bin/freeman2sdp -f FichiersTmp/contour.fc > FichiersTmp/contour.sdp;

SIZE=$(cat FichiersTmp/size.txt);
/usr/local/bin/pgmTrans -setBlack 160 -setMinBlack 254 < $NAME > /tmp/tmp.pgm
convert /tmp/tmp.pgm FichiersTmp/imageFond.png;


/usr/bin/testSampling  -afficheVecteurisation ${WIDTH} CENTER     -afficheContourXFIG 0 0 -enteteXFIG -estimGMCB ${WIDTH} -afficheImage imageFond.png ${SIZE}  < FichiersTmp/contour.sdp  > FichiersTmp/tmp.fig 2> FichiersTmp/log.txt

fig2dev -L eps FichiersTmp/tmp.fig  FichiersTmp/tmp.eps  2> FichiersTmp/log3.txt;

echo "Curvature Based Contour Reconstruction E=${WIDTH} <BR>" > FichiersTmp/info.txt  ;
cat FichiersTmp/log.txt |grep "of segments" >> FichiersTmp/info.txt; 
echo "<BR> " >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "of arcs" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Curvature GMCB" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Segmentation time:" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Execution time:" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Nb points" >> FichiersTmp/info.txt; 



# Sauvegarde des fichiers sources dans l'archive
#cp ${NAME} FichiersTmp/contourSRC.fc;
#/usr/local/bin/freeman2pgm -d 2 -auto_center   < FichiersTmp/contourSRC.fc  > FichiersTmp/contourSRC.pgm 
#convert FichiersTmp/contourSRC.pgm FichiersTmp/contourSRC.gif;


epstopdf  FichiersTmp/tmp.eps;
pdftoppm FichiersTmp/tmp.pdf FichiersTmp/tmp.ppm ;
convert FichiersTmp/tmp.ppm-1.ppm FichiersTmp/tmp.gif;









