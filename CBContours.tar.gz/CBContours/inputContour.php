


<hr color=#330090   align=left > 

<form method="post" enctype="multipart/form-data" action="index.php">
<p>
<TABLE  >
<TR>
<TD> <img src="ImagesExamples/cheval3.png" width=120px >  </TD>
<TD> <img src="ImagesExamples/klokan.gif" width=150px >  </TD>
<TD> <img src="ImagesExamples/castle2.gif" width=120px >  </TD></TR>
<TR>
<td align=center> <input type="radio" name="sampleNum" value="1"> </td>
<td align=center> <input type="radio" name="sampleNum" value="2"> </td>
<td align=center> <input type="radio" name="sampleNum" value="3"  > </td></TR>

<TR>
<TD> <img src="ImagesExamples/female.png" width=150px >  </TD>
<TD> <img src="ImagesExamples/spirale2.gif" width=150px >  </TD>
</TR>

<TR>

<td align=center> <input type="radio" name="sampleNum" value="4"  > </td>
<td align=center> <input type="radio" name="sampleNum" value="5"  > </td>
</TR>
</TABLE>
<td align=center>
</td>


<br>

<br>
<select name="algo" onchange="">
   <option value="CBR">Curvature Based Reconstruction (GMC) [1] </option>
   <option value="BCC">Curvature Based Reconstruction (BCCA) [2] </option>
   <option value="NAR">Nguyen Arcs Reconstruction (NASR) [3]</option>
   <option value="VC">Visual Curvature (VC) [4] </option>

</select>
   scale:
<select name="width" onchange="">
<option value="2">2</option>
<option value="3">3</option>
<option value="4">4</option>
<option value="5">5</option>
<option value="6">6</option>
<option value="7">7</option>
<option value="8">8</option>
<option value="9">9</option>
<option value="10">10</option>
<option value="11">11</option>
<option value="12">12</option>
<option value="13">13</option
<option value="14">14</option>
<option value="15">15</option>
<option value="16">16</option>
<option value="17">17</option>
<option value="18">18</option>
<option value="19">19</option>
<option value="20">20</option>
<option value="30">30</option>
<option value="40">40</option>

</select>
<BR>
   Compute Hausdorff error (complexity O(N2)) <input type="radio" name="hausdorff" value="compError">
<BR>


<input type="hidden" name="inputImagePosted" value="non">
<input type="hidden" name="inputContourPosted" value="ok">
<input type="submit" name="computeBoxes" value="Compute representation">

</p>
</form>
