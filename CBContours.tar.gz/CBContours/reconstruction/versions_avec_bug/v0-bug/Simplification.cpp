#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <list>
//#include <Magick++.h>

#include <Droite.hpp>
#include <SolvePolytope.hpp>
#include <Pixel.hpp>
#include <ImageDiscrete.hpp>
#include <GenererPov.hpp>

//using namespace Magick;

int main(int nb_args,char** args) {

	std::cout << "\n************************\n** DEBUT DE PROGRAMME **\n************************";

	//DECLARATION DES VARIABLES LOCALES
	std::list<Pixel> LP;
	std::list<Pixel>::iterator LP_it;
	Droite madroite;
	int nbr_sommets=0;
	ImageDiscrete id;
	
	std::cout << "> ESTIMATEUR DE BRUIT: ANALYSE DE CONTOUR (Kerautret&Lachaud) \n";
	std::cout << "\n** CHARGEMENT DE LA COURBE 'noiseLevel.txt' \n";
	int x,y,taille,trash,cpt;
	std::fstream file("noiseLevel.txt");
	std::string line;
	cpt=0;
	while ( getline( file, line ) ) {
		std::istringstream myiss(line);
		myiss >> trash;
		myiss >> taille;
		myiss >> trash;
		myiss >> x;
		myiss >> y;
		Pixel p(x,y);
		p.setInf(taille);
		LP.push_back(p);
		cpt++;
	}
	std::cout << "\n** COURBE JACQUO CHARGEE     TOTAL: " << cpt << " PIXELS \n";

//********************

	//RECONSTRUCTION
	std::cout << "\n** RECONSTRUCTION DE LA COURBE";

	LP_it=LP.begin();
	std::cout << "\n->LISTE DES SOMMET: \n";
	while (LP_it != LP.end()) {
		nbr_sommets++;
		std::cout << (*LP_it).getX() << " " << (*LP_it).getY() << "\n"; 
		//Initialisation des espaces de param�tres (positifs et n�gatifs)
		SolvePolytope spplus(1); 
		SolvePolytope spmoins(-1); 
		bool solplus=true; bool solmoins=true; //vrai tant que les polytopes non nuls
		int lg_segment=0; 
		int lg_pos=0; 
		int lg_neg=0;
		//Tant qu'on reconnait un segment, on continue (sauf si on est en fin de courbe)
		while ((solplus || solmoins) && (LP_it!=LP.end())) {
			lg_segment++;
			//Dans le demi-plan positif
			if (solplus) {
				//std::cout << "\n*    Dans SOLPLUS: ";
				if (!spplus.ajouterPixel(*LP_it)) { 
					solplus=false; 
					lg_pos=lg_segment;
					//std::cout << "REJETE";
				}
				//else std::cout << "ACCEPTE";
			}
			//Dans le demi-plan n�gatif
			if (solmoins) {
				//std::cout << "\n*    Dans SOLMOINS: ";
				if (!spmoins.ajouterPixel(*LP_it)) {
				       	solmoins=false;
					lg_neg=lg_segment;
					//std::cout << "REJETE";
				}
				//else std::cout << "ACCEPTE";
			}
			if (solplus || solmoins) { LP_it++; }
			else {LP_it--;}
		}
		//Le segment le plus long a �t� reconnu, on dessine le polytope contenant toutes les solutions
	}
	std::cout << "->OBJET RECONSTRUIT EN " << nbr_sommets << " SEGMENTS\n"; 

//img->write("simple.png");

	std::cout << "\n************************\n**  FIN DE PROGRAMME  **\n************************\n\n";
	return 0;
}

