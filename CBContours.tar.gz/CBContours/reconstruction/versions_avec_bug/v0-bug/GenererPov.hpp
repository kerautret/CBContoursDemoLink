#ifndef GENERERPOV_H
#define GENERERPOV_H

#include <iostream>
#include <fstream>
#include <list>
#include <Pixel.hpp>
#include <string>
#include <math.h>
#include <SolvePolytope.hpp>

class GenererPov
{
	//Membres de la classe
	std::ofstream ofs;

	public:
	//Constructeurs
	GenererPov();	
	GenererPov(std::string&);

	//Destructeur
	~GenererPov();

	//Initialisation du fichier pov
	void ecrire_entete_redim(int);
	void ecrire_entete_polytope(int);

	//Ajouter une ligne
	void ajouterLigne(char*);

	void dessinerLigne(double,double,double,double,double);

	//Dessine le polytope
	void dessinerPolytope(std::list<Intersection>);

	GenererPov &operator<<(Pixel const &);

};

#endif

