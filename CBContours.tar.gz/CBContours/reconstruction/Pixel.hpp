#ifndef PIXEL_H
#define PIXEL_H

class Pixel
{
	int xx; //abcisse du voxel
	int yy; //ordonn�e du voxel
	int info; //information concernant le Pixel (taille)

	public:
	//Constructueurs
	Pixel();
	Pixel(int,int);
	Pixel(int,int,int);

	//Destructeur
	~Pixel();

	//Accesseurs
	int getX() const;
	int getY() const;
	int getInf() const;

	//Modifier
	void setInf(int);
	void incrInf();

	//Fonctions Statiques
	static int linearise(int,int,int,int);

	Pixel &operator=(const Pixel &source);
	bool operator!=(const Pixel &source);
	bool operator==(const Pixel &source);
};

#endif

