<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> MS Polygon demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php $NumPageEnCours=3; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 20  (ID: Archive_1131350710317)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1131350710317/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1131350710317/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1131350710317/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1131350710317/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1131350710317/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1131350710317/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (GMCB) E=1 <BR> Number of segments: 10 <BR> Number of arcs: 55 <BR> Curvature GMCB time: 65 ms <BR> Segmentation time: 10 ms <BR> Total Execution time: 75 ms
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 21  (ID: Archive_1805440090118)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1805440090118/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1805440090118/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1805440090118/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1805440090118/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1805440090118/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1805440090118/polygon.txt>polygon.txt</a> <br>  
Nguyen Arcs Segment Reconstruction (NASR) E=6 <BR> <BR> <BR> <BR> <BR> <BR> <BR> Hausdorff error: 0
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 22  (ID: Archive_0608041550618)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_0608041550618/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_0608041550618/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_0608041550618/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_0608041550618/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_0608041550618/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_0608041550618/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (GMCB) E=1 <BR> Number of segments: 7 <BR> Number of arcs: 44 <BR> Curvature GMCB time: 39 ms <BR> Segmentation time: 10 ms <BR> Total Execution time: 49 ms
 </TD></TR>  </TABLE> 
</DIV>
</DIV>

	
	</BODY>
</HTML> 
