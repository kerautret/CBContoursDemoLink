#include<SolvePolytope.hpp>
#include<iostream>

/** classe d�finit le point intersection de deux droites
	//Membres
	Droite* d1;
	Droite* d2;
	double XX;
	double YY;
	bool existe;
	*/

//Constructeurs
Intersection::Intersection(Droite* droite1,Droite* droite2){
	d1=droite1;
	d2=droite2;
	existe=true;
	//Calcul des abscisses et ordonn�es de l'intersection
	if ((*d1).getB()==0) {//d1 est verticale (d2 affine)
		XX=(-(*d1).getC())/((*d1).getA());
		YY=(*d2).getVal(XX);
	}
	else if ((*d1).getB()==0) {//d2 est verticale (d1 affine)
		XX=(-(*d2).getC())/((*d2).getA());
		YY=(*d1).getVal(XX);
	}
	else{//aucune des droites n'est verticale: X=(c2/b2-c1/b1)/(a1/b1-a2/b2)
		XX=((( (*d2).getC() )/( (*d2).getB() )) 
		   -(( (*d1).getC() )/( (*d1).getB() ))) 
		  /((( (*d1).getA() )/( (*d1).getB() ))
		   -(( (*d2).getA() )/( (*d2).getB() )));
		YY=(*d1).getVal(XX);
	}

}

//Destructeur
Intersection::~Intersection(){}

//Accesseurs
Droite& Intersection::getD1() { return *d1;}
Droite& Intersection::getD2() { return *d2;}
double Intersection::getX() { return XX; }
double Intersection::getY() { return YY; }

//Modifiers
void Intersection::setD1(Droite* dd) { d1=dd; }
void Intersection::setD2(Droite* dd) { d2=dd; }

