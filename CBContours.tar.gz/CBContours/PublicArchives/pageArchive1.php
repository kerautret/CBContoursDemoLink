<HTML>

	<HEAD>
		<TITLE>test</TITLE>
		<LINK type="text/css" rel="stylesheet" href="http://kerrecherche.iutsd.uhp-nancy.fr/MeaningfulBoxes/demoStyle.css">
		
	</Head>
		
	<BODY>



		<DIV id="conteneur">


		  





   <h2> MS Polygon demo</h2>
       <a align=left color=white  href="../index.php" > back demo page </a>
<br>


<?php \$NumPageEnCours=1; include("indexArchives.php") ?>
<HR linewidth=1px>
<div id="archive" >
Archive 1  (ID: Archive_1815462620910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1815462620910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1815462620910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1815462620910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1815462620910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1815462620910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1815462620910/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction E=2 <BR> Number of segments: 3 <BR> Number of arcs: 185 <BR> Curvature GMCB time: 990 ms <BR> Segmentation time: 529 ms <BR> Total Execution time: 1519 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 2  (ID: Archive_1817132620910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1817132620910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1817132620910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1817132620910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1817132620910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1817132620910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1817132620910/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction E=2 <BR> Number of segments: 2 <BR> Number of arcs: 25 <BR> Curvature GMCB time: 218 ms <BR> Segmentation time: 30 ms <BR> Total Execution time: 248 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 3  (ID: Archive_1831092620910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1831092620910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1831092620910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1831092620910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1831092620910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1831092620910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1831092620910/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction E=5 <BR> Number of segments: 1 <BR> Number of arcs: 31 <BR> Curvature GMCB time: 1164 ms <BR> Segmentation time: 220 ms <BR> Total Execution time: 1384 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 4  (ID: Archive_1831342620910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1831342620910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1831342620910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1831342620910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1831342620910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1831342620910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1831342620910/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction E=5 <BR> Number of segments: 33 <BR> Number of arcs: 4 <BR> <BR> <BR> Execution time: 515 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 5  (ID: Archive_1052062720910)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1052062720910/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1052062720910/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1052062720910/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1052062720910/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1052062720910/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1052062720910/polygon.txt>polygon.txt</a> <br>  
Curvature Based Contour Reconstruction (GMCB) E=2 <BR> Number of segments: 0 <BR> Number of arcs: 22 <BR> Curvature GMCB time: 173 ms <BR> Segmentation time: 23 ms <BR> Total Execution time: 196 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 6  (ID: Archive_1101190670311)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1101190670311/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1101190670311/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1101190670311/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1101190670311/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1101190670311/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1101190670311/polygon.txt>polygon.txt</a> <br>  
Nguyen Arcs Segment Reconstruction (NASR) E=2 <BR> Number of segments: 188 <BR> Number of arcs: 32 <BR> <BR> <BR> Execution time: 1108 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 7  (ID: Archive_1143330670311)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1143330670311/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1143330670311/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1143330670311/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1143330670311/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1143330670311/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1143330670311/polygon.txt>polygon.txt</a> <br>  
Nguyen Arcs Segment Reconstruction (NASR) E=2 <BR> Number of segments: 188 <BR> Number of arcs: 32 <BR> <BR> <BR> Execution time: 1108 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 8  (ID: Archive_1147150670311)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1147150670311/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1147150670311/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1147150670311/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1147150670311/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1147150670311/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1147150670311/polygon.txt>polygon.txt</a> <br>  
Nguyen Arcs Segment Reconstruction (NASR) E=2 <BR> Number of segments: 188 <BR> Number of arcs: 32 <BR> <BR> <BR> Execution time: 1108 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
<HR linewidth=1px>
<div id="archive" >
Archive 9  (ID: Archive_1150070670311)
<TABLE> <TR> <TD> <IMG width=150px SRC= Archive_1150070670311/contourSRC.gif ></TD> 
    <TD><IMG width=150px SRC= Archive_1150070670311/tmp.gif > </TD></TR>
          <TR><TD>
    <a href=Archive_1150070670311/contourSRC.gif>contourSRC.gif</a> <br>
    <a href=Archive_1150070670311/contourSRC.fc>contourSRC.fc</a> <br>
    </TD>
    <TD><a href=Archive_1150070670311/tmp.pdf>result.pdf</a> <BR>
    <a href=Archive_1150070670311/polygon.txt>polygon.txt</a> <br>  
Nguyen Arcs Segment Reconstruction (NASR) E=2 <BR> Number of segments: 188 <BR> Number of arcs: 32 <BR> <BR> <BR> Execution time: 1108 ms <BR>
 </TD></TR>  </TABLE> 
</DIV>
