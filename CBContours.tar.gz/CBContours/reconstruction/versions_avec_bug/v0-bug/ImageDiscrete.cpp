#include <ImageDiscrete.hpp>
#include <Pixel.hpp>

//Constructeurs
ImageDiscrete::ImageDiscrete() { xmax=0; ymax=0; seuil=4; fact=0.5;}
ImageDiscrete::ImageDiscrete(int s,double f) { xmax=0; ymax=0; seuil=s; fact=f;}

//Destructeur
ImageDiscrete::~ImageDiscrete() {}

//Accesseurs
int ImageDiscrete::getDim() { if (xmax>=ymax) return xmax; else return ymax; }

std::list<Pixel>& ImageDiscrete::getList() { return listepixels; }

/* Charge la courbe depuis le fichier "courbe.txt" dans la liste des pixels
 * important: la courbe doit �tre 1-connexe et ferm�e
 */
void ImageDiscrete::loadPic(){
	listepixels.clear();	
	int x,y,cpt;
	std::fstream file("courbe.txt");
	std::string line;
	cpt=0;
	while ( getline( file, line ) ) {
		std::istringstream myiss(line);
		myiss >> x;
		myiss >> y;
		Pixel p(x,y);
		if (x>=xmax) xmax=x;
		if (y>=ymax) ymax=y;
		listepixels.push_back(p);
		cpt++;
	}
	std::cout << "\n** CHARGEMENT DE LA COURBE TERMINE\n  -> taille de l'image:" << xmax << " X  " << ymax << std::endl;
	std::cout << "** TOTAL: " << cpt << " PIXELS \n";
}

/*Parcours tous les pixels de la liste et les �tiquette avec la moiti� de la taille
 * de leur tangente sym�trique
 */
void ImageDiscrete::createLabel(){
	std::cout << "\n** CALCUL DES TANGENTES DISCRETES SYMETRIQUES" << std::endl;
	//iterateur sur le pixel a �tiqueter
	std::list<Pixel>::iterator it = listepixels.begin();
	//iterateur sur les pixels suivants/pr�c�dents du segment de droite � tester
	std::list<Pixel>::iterator it_first = listepixels.begin();
	std::list<Pixel>::iterator it_last = listepixels.begin();
	int longueur=0; //demi-longueur du segment test�
	bool test; 
/** ALGORITHM **/
	/* initialisation */
	//std::cout << "**************\n** PIXEL 1  **\n**************\n";
	precedant(it_first);suivant(it_last);longueur++;
       	precedant(it_first);suivant(it_last);longueur++;
	test=estUnSegment(it_first,it_last);
	//premier pixel, la tangente est de taille inconnue, on continue tant que le test est vrai
	while(test) {
		precedant(it_first);suivant(it_last);longueur++;
		test=estUnSegment(it_first,it_last);
	}
	//si le test �tait faux pour longueur=2, cela signifie que longueur=1
	if (longueur==2) {
		(*it).setInf(1);
		suivant(it_first);it++;suivant(it_last); 
	//sinon, on m�morise longueur-1 et on fait glisser la fen�tre en diminuant sa longueur de 1
	} else {
		(*it).setInf(longueur-1);
		suivant(it_first);suivant(it_first);it++;longueur--;
	}
	/* calcul pour tous les pixels */
	int cpt=1;
	while(it!=listepixels.end()){
		cpt++;
		//std::cout << "**************\n** PIXEL " << cpt << "\n**************\n";
		if(estUnSegment(it_first,it_last)) {
			precedant(it_first);suivant(it_last);longueur++;
			if(estUnSegment(it_first,it_last)) {
				(*it).setInf(longueur);
				suivant(it_first);it++;suivant(it_last);
			}
			else {
				(*it).setInf(longueur-1);
				suivant(it_first);suivant(it_first);it++;longueur--;
			}
		} else {
			(*it).setInf(longueur-1);		
			suivant(it_first);suivant(it_first);it++;longueur--;
		}
		//si la fen�tre est trop petite, on la redimensionne: longueur=2
		if ((*it_first)==(*it_last)) {
			it_first=it; precedant(it_first); precedant(it_first);
	       		it_last=it; suivant(it_last); suivant(it_last);
			longueur=2;
		}

	}

/** FIN ALGO **/
	//std::cout << "\n\n** CALCUL TERMINE" << std::endl;
}




/* ********************************************************************
 * ********************************************************************
 * ********************************************************************
 * */

//Retourne vrai si l est un segment discret, algorithme de debled-renesson
bool ImageDiscrete::estUnSegment(std::list<Pixel>::iterator itdebut,std::list<Pixel>::iterator itfin){
	//std::cout << "** -> TESTER LE SEGMENT(" << (*itdebut).getX() << "," << (*itdebut).getY() << ")";
	//std::cout << "(" << (*itfin).getX() << "," << (*itfin).getY() << ") \n";
	
/*D�termination de l'octant auquel appartient le segment
 * et �limination des cas triviaux */
	//calcul du code de freeman 
	std::list<Pixel>::iterator M=itdebut;
	int valA=8; int valB=8;	int tmp;
	int factX=1; int factY=1; //facteurs multiplicatifs
	while( (*M) != (*itfin) ) {
		Pixel p1=(*M); suivant(M); Pixel p2=(*M);
		tmp=codefree(p1,p2);
		if (valA==8) valA=tmp;
		else if (valA!=tmp){
			if (valB==8) valB=tmp;
			else if (valB!=tmp) {
				//std::cout << "        -> NON (trois directions diff�rentes)\n";
			       	return false;	
	} 	}	}
	if (valA > valB) { tmp=valA; valA=valB; valB=tmp; }
	if (valB==8) {
		//std::cout << "        -> OUI (une seule direction)\n";
		return true;
	}
	//d�termination de l'octant et mise � jour des facteurs multiplicatifs
	else {
		//std::cout << "directions: " << valA << " et " << valB;
		if (valA==0) {
			if (valB==1) {
				//std::cout << " => premier octant\n";
			} else if (valB==3) {
				//std::cout << " => quatrieme octant\n";
				factY=-1;
			} //else std::cout << "\nERREUR\nERREUR\nERREUR\n";
		} else if (valA==1) {
			if (valB==2) {
				//std::cout << " => deuxi�me octant\n";
				factX=-1;
			} //else std::cout << "\nERREUR\nERREUR\nERREUR\n";
		} else if (valA==2){
			if (valB==3) {
				//std::cout << " => troisieme octant\n";
				factX=-1; factY=-1;
			} //else std::cout << "\nERREUR\nERREUR\nERREUR\n";
		}
	}
/* ALGORITHM DEBLED-RENESSON */
	//VARIABLES ET INITIALISATION
	int a=0, b=1, mu=0;
	std::list<Pixel>::iterator UF,LF, UL, LL;
	M=itdebut;
	int X0=(*M).getX()*(factX); int Y0=(*M).getY()*(factY);
	UF=itdebut; LF=itdebut;	
	UL=itdebut; LL=itdebut;
	int rM;

	//CORPS
	//premier et troisi�me octants
	if (factX*factY==1) {
	while( (*M) != (*itfin) ) {
		suivant(M);
		int yM=(*M).getY()*(factY)-Y0;
		int xM=(*M).getX()*(factX)-X0+yM; 
		rM=a*xM-b*yM;
		if (rM==(mu-1)) {
			LF=LL; UL=M;
			a=yM-( (*UF).getY()*(factY)-Y0 );
			b=xM-( (*UF).getX()*(factX)-X0 )+( (*UF).getY()*(factY)-Y0 );
			mu=a*xM-b*yM;
		} else if (rM==(mu+b)) {
			UF=UL; LL=M;
			a=yM-((*LF).getY()*(factY)-Y0);
			b=xM-((*LF).getX()*(factX)-X0)+((*LF).getY()*(factY)-Y0);
			mu=a*xM-b*yM-b+1;
		} else if ((rM < (mu-1))||(rM > (mu+b))) {
			//std::cout << "        -> NON\n";
			return false;
		} else if (rM==mu) UL=M;
		else if (rM==(mu+b-1)) LL=M;
	}
	}
	//deuxi�me et quatri�me octants
	else if (factX*factY==-1) {
	while( (*M) != (*itfin) ) {
		suivant(M);
		int xM=(*M).getX()*(factX)-X0; 
		int yM=(*M).getY()*(factY)-Y0+xM;
		rM=a*yM-b*xM;
		if (rM==(mu-1)) {
			LF=LL; UL=M;
			a=xM-( (*UF).getX()*(factX)-X0 );
			b=yM-( (*UF).getY()*(factY)-Y0 )+( (*UF).getX()*(factX)-X0 );
			mu=a*yM-b*xM;
		} else if (rM==(mu+b)) {
			UF=UL; LL=M;
			a=xM-((*LF).getX()*(factX)-X0);
			b=yM-((*LF).getY()*(factY)-Y0)+((*LF).getX()*(factX)-X0);
			mu=a*yM-b*xM-b+1;
		} else if ((rM < (mu-1))||(rM > (mu+b))) {
			//std::cout << "        -> NON\n";
			return false;
		} else if (rM==mu) UL=M;
		else if (rM==(mu+b-1)) LL=M;
	}
	}
	//si aucune erreur n'a �t� rencontr�e, on a bien un segment de droite discr�te
	//std::cout << "        -> OUI\n";
	return true;
}


//incr�mente l'it�rateur tel qu'il boucle sur la liste
void ImageDiscrete::suivant(std::list<Pixel>::iterator& iter){
	iter++;
	if (iter==listepixels.end()) iter=listepixels.begin();
}

//d�cr�mente l'it�rateur tel qu'il boucle sur la liste
void ImageDiscrete::precedant(std::list<Pixel>::iterator& iter){
	if (iter==listepixels.begin()) {
		iter=listepixels.end();
	}
	iter--;
}

// donne le code de freeman de (pixel1,pixel2) 0=droite 1=haut 2=gauche 3=bas
int ImageDiscrete::codefree(Pixel pixel1,Pixel pixel2) {
	int deltaX=pixel2.getX()-pixel1.getX();
	int deltaY=pixel2.getY()-pixel1.getY();
	if (deltaX==1){
		return 0;
	} else if (deltaY==1) {
		return 1;
	} else if (deltaX==-1) {
		return 2;
	} else if (deltaY==-1) {
		return 3;
	} else {
		/*
		std::cout << "pixels (" << pixel1.getX() << "," << pixel1.getY() << ") (" << pixel2.getX() << "," << pixel2.getY() << ")\n";
		std::cout << "code freeman FATAL ERROR\n";
		*/
		return 8;
	}
}

