#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <list>



#include <SolvePolytope.hpp>
#include <Pixel.hpp>

#include "ImaGene/base/Arguments.h"
#include "ImaGene/base/Proxy.h"
#include "ImaGene/dgeometry2d/C4CGeometry.h"
#include "ImaGene/dgeometry2d/C4CSegmentPencil.h"
#include "ImaGene/base/Vector2i.h"
#include "ImaGene/base/Arguments.h"
#include "ImaGene/base/StandardArguments.h"
#include "ImaGene/mathutils/Mathutils.h"
#include "ImaGene/mathutils/Statistics.h"
#include "ImaGene/timetools/Clock.h"
#include "ImaGene/dgeometry2d/C4CTangentialCover.h"
#include "ImaGene/helper/C4CTangentialCoverGeometry.h"
#include "ImaGene/dgeometry2d/FreemanChain.h"
#include "ImaGene/dgeometry2d/FreemanChainTransform.h"
#include "ImaGene/dgeometry2d/C4CIteratorOnFreemanChain.h"
#include "ImaGene/digitalnD/C4CIteratorOnFreemanChainSurface.h"
#include "ImaGene/digitalnD/KnSpace.h"
#include "ImaGene/digitalnD/C4CIteratorOnSurface.h"
#include "ImaGene/helper/ShapeHelper.h"
#include "ImaGene/helper/MultiscaleProfile.h"
#include "ImaGene/helper/DrawingXFIG.h"
using namespace ImaGene;
using namespace std;
static ImaGene::Arguments args;

int main(int nb_args,char** argv) {

  StandardArguments::addIOArgs( args, true, false );
  
  FreemanChain fc; 
  istream & in_str = StandardArguments::openInput( args );
  FreemanChain::read( in_str, fc );
  if ( ! in_str.good() )
    {
      cerr << "Error reading Freeman chain code." << endl;
      return 2;
    }
  
  Clock::startClock();
  cerr << "starting computing multi resolution and analysis defined on " << fc.chain.size() << endl;
  FreemanChainSubsample fcsub( 1, 1, 0, 0 );
  FreemanChainCleanSpikesCCW fccs(5 );
  FreemanChainCompose fcomp( fccs, fcsub );
  FreemanChainTransform* ptr_fct = &fcomp;
  FreemanChainSubsample* ptr_fcsub = &fcsub;
  
  MultiscaleProfile MP;
  MP.chooseSubsampler( *ptr_fct, *ptr_fcsub );
  MP.init( fc, 15 );
  long timeMS = Clock::stopClock();
  cerr<< "Multi-scale computed in: " << timeMS << " ms." << endl;
  cerr << "Nb points initial contour: " << fc.size() << endl;

	std::cout << "\n************************\n** DEBUT DE PROGRAMME **\n************************\n";

	//********************
	//DECLARATION DES VARIABLES LOCALES
	std::list<Pixel> LP; //liste des pixel ORDONNEE du contour
	std::list<Pixel>::iterator LP_it;
	//DECLARATION DES VARIABLES LOCALES
	Droite madroite;
	int nbr_sommets=0;

	
	
	uint i =0;
	//std::cout << "** PIXELS DU CONTOUR:\n ";

	for (FreemanChain::const_iterator it = fc.begin() ; it!=fc.end(); ++it){
	  uint noiseLevel =  MP.noiseLevel(i, 1,0.0);
	  Pixel p((*it).x(), (*it).y());
	  p.setInf(noiseLevel);
	  LP.push_back(p);
		//std::cout << "" << (*it).x() << " " << (*it).y() << "\n";
	  i++;
	}
	
	//  std::cerr << "Noise Level done. " << endl;
	//********************
	//RECONSTRUCTION
	std::cout << "\n** RECONSTRUCTION DE LA COURBE";
	std::cout << "\n\n->LISTE DES SOMMET: \n";

	LP_it=LP.begin();
	

	//à chaque boucle du while, on reconnait un nouveau segment
	while (LP_it != LP.end()) {
		nbr_sommets++;
		//on affiche les coordonnées du pixels à partir duquel on commence la reconnaissance de segment
		std::cout << (*LP_it).getX() << " " << (*LP_it).getY() << "\n"; 

		//Initialisation des espaces de paramètres (positifs et négatifs)
		SolvePolytope spplus(1); 
		SolvePolytope spmoins(-1); 
		bool solplus=true; bool solmoins=true; //vrai tant que les polytopes non nuls

		//à chaque boucle du while, on ajoute un pixel au segment en cours de reconnaissance
		while ((solplus || solmoins) && (LP_it!=LP.end())) {

			//On ajoute les contraintes liées au pixel dans le demi-plan positif
			if (solplus) {
				if (!spplus.ajouterPixel(*LP_it)) { solplus=false; }
			}

			//On ajoute les contraintes liées au pixel dans le demi-plan négatif
			if (solmoins) {
				if (!spmoins.ajouterPixel(*LP_it)) { solmoins=false; }
			}

			//si les polytopes sont non nuls, on essais d'ajouter le pixel suivant au segment reconnu
			if (solplus || solmoins) { LP_it++; }
			//sinon, on essais de reconnaitre un nouveau segment à partir du pixel précédent (on sort du premier while)
			else {LP_it--;}
		}
		//segment maximal reconnu, on passe au suivant
	}

	//********************
	std::cout << "->OBJET RECONSTRUIT EN " << nbr_sommets << " SOMMETS\n"; 
	std::cout << "\n************************\n**  FIN DE PROGRAMME  **\n************************\n\n";
	return 0;
}

