#include <Pixel.hpp>
#include <iostream>

//constructeurs
Pixel::Pixel() {
	xx=0; yy=0; info=1;
}

Pixel::Pixel(int a,int b){
	xx=a; yy=b; info=1;
}

Pixel::Pixel(int a, int b, int i){
	xx=a; yy=b; info=i;
}

//destructeur
Pixel::~Pixel() {}

//accesseurs
int Pixel::getX() const { return xx; }
int Pixel::getY() const { return yy; } 
int Pixel::getInf() const { return info; }

//modifier
void Pixel::setInf(int newinf){ info=newinf; }
void Pixel::incrInf() {	info++; }

Pixel& Pixel::operator=(const Pixel &source){ xx=source.getX(); yy=source.getY(); info=source.getInf(); return *this;}

bool Pixel::operator!=(const Pixel &source){ return !( (xx==source.getX()) && (yy==source.getY()) ); }

bool Pixel::operator==(const Pixel &source){ return ( (xx==source.getX()) && (yy==source.getY()) ); }

