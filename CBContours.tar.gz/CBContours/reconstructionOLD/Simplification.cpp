#include <iostream>
#include <fstream>
#include <sstream>
#include <math.h>
#include <list>
//#include <Magick++.h>

#include <Droite.hpp>
#include <SolvePolytope.hpp>
#include <Pixel.hpp>
#include <ImageDiscrete.hpp>
#include <GenererPov.hpp>

#include "ImaGene/base/Arguments.h"
#include "ImaGene/base/Proxy.h"
#include "ImaGene/dgeometry2d/C4CGeometry.h"
#include "ImaGene/dgeometry2d/C4CSegmentPencil.h"
#include "ImaGene/base/Vector2i.h"
#include "ImaGene/base/Arguments.h"
#include "ImaGene/base/StandardArguments.h"
#include "ImaGene/mathutils/Mathutils.h"
#include "ImaGene/mathutils/Statistics.h"
#include "ImaGene/timetools/Clock.h"
#include "ImaGene/dgeometry2d/C4CTangentialCover.h"
#include "ImaGene/helper/C4CTangentialCoverGeometry.h"
#include "ImaGene/dgeometry2d/FreemanChain.h"
#include "ImaGene/dgeometry2d/FreemanChainTransform.h"
#include "ImaGene/dgeometry2d/C4CIteratorOnFreemanChain.h"
#include "ImaGene/digitalnD/C4CIteratorOnFreemanChainSurface.h"
#include "ImaGene/digitalnD/KnSpace.h"
#include "ImaGene/digitalnD/C4CIteratorOnSurface.h"
#include "ImaGene/helper/ShapeHelper.h"
#include "ImaGene/helper/MultiscaleProfile.h"
#include "ImaGene/helper/DrawingXFIG.h"

using namespace ImaGene;
using namespace std;

static ImaGene::Arguments args;

//using namespace Magick;

int main(int nb_args,char** argv) {
  StandardArguments::addIOArgs( args, true, false );
  
  FreemanChain fc; 
  istream & in_str = StandardArguments::openInput( args );
  FreemanChain::read( in_str, fc );
  if ( ! in_str.good() )
    {
      cerr << "Error reading Freeman chain code." << endl;
      return 2;
    }
  
  Clock::startClock();
  cerr << "starting computing multi resolution and analysis defined on " << fc.chain.size() << endl;
  FreemanChainSubsample fcsub( 1, 1, 0, 0 );
  FreemanChainCleanSpikesCCW fccs(5 );
  FreemanChainCompose fcomp( fccs, fcsub );
  FreemanChainTransform* ptr_fct = &fcomp;
  FreemanChainSubsample* ptr_fcsub = &fcsub;
  
  MultiscaleProfile MP;
  MP.chooseSubsampler( *ptr_fct, *ptr_fcsub );
  MP.init( fc, 15 );
  long timeMS = Clock::stopClock();
  cerr<< "Multi-scale computed in: " << timeMS << " ms." << endl;
  cerr << "Nb points initial contour: " << fc.size() << endl;
  
  Clock::startClock();
  //DECLARATION DES VARIABLES LOCALES
  std::list<Pixel> LP;
  std::list<Pixel>::iterator LP_it;
  Droite madroite;
  int nbr_sommets=0;
  ImageDiscrete id;
  
  
  uint i =0;
  for (FreemanChain::const_iterator it = fc.begin() ; it!=fc.end(); ++it){
    uint noiseLevel =  MP.noiseLevel(i, 1,0.0);
    Pixel p((*it).x(), (*it).y());
    p.setInf(noiseLevel);
    LP.push_back(p);
    i++;
  }
  //  std::cerr << "Noise Level done. " << endl;

  //********************
  //RECONSTRUCTION
  //  std::cerr << "\n** RECONSTRUCTION DE LA COURBE";
  
  LP_it=LP.begin();
  //std::cout << "\n->LISTE DES SOMMET: \n";
  while (LP_it != LP.end()) {
    nbr_sommets++;
    std::cout << (*LP_it).getX() << " " << (*LP_it).getY() << "\n"; 
    //Initialisation des espaces de param�tres (positifs et n�gatifs)
    SolvePolytope spplus(1); 
    SolvePolytope spmoins(-1); 
    bool solplus=true; bool solmoins=true; //vrai tant que les polytopes non nuls
    int lg_segment=0; 
    int lg_pos=0; 
    int lg_neg=0;
    //Tant qu'on reconnait un segment, on continue (sauf si on est en fin de courbe)
    while ((solplus || solmoins) && (LP_it!=LP.end())) {
      lg_segment++;
      //Dans le demi-plan positif
      if (solplus) {
	//std::cout << "\n*    Dans SOLPLUS: ";
	if (!spplus.ajouterPixel(*LP_it)) { 
	  solplus=false; 
	  lg_pos=lg_segment;
	  //std::cout << "REJETE";
	}
	//else std::cout << "ACCEPTE";
      }
      //Dans le demi-plan n�gatif
      if (solmoins) {
	//std::cout << "\n*    Dans SOLMOINS: ";
	if (!spmoins.ajouterPixel(*LP_it)) {
	  solmoins=false;
	  lg_neg=lg_segment;
	  //std::cout << "REJETE";
	}
	//else std::cout << "ACCEPTE";
      }
      if (solplus || solmoins) { LP_it++; }
      else {LP_it--;}
    }
    //Le segment le plus long a �t� reconnu, on dessine le polytope contenant toutes les solutions
  }
  //img->write("simple.png");
  long timeRec = Clock::stopClock();
  cerr << "Reconstruction time: " << timeRec << " ms."<<endl;
  cerr << "Total: " << (timeRec+timeMS) << " ms." << endl;
  return 0;
}

