#!/bin/sh


#copie fichiers resultats temporaires dans un répertoire archive:

ID=$(date +%H%M%S%j%m%y);









NAMEREP="/home/kerautre/Sites/CBContours/PublicArchives/Archive_$ID";
mkdir ${NAMEREP};

cp /home/kerautre/Sites/CBContours/FichiersTmp/tmp.gif  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/tmp.eps  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/tmp.pdf  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/tmp.fig  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/log.txt  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/polygon.txt  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/info.txt  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/contourSRC.fc  ${NAMEREP}/ ;
cp /home/kerautre/Sites/CBContours/FichiersTmp/contourSRC.gif  ${NAMEREP}/ ;











