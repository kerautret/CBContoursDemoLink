 
<a href=pageArchive1.php <?php if($NumPageEnCours == 1){ echo('style="color:#FFFFFF"');} ?> > [1] </a>
<a href=pageArchive2.php <?php if($NumPageEnCours == 2){ echo('style="color:#FFFFFF"');} ?> > [2] </a>
<a href=pageArchive3.php <?php if($NumPageEnCours == 3){ echo('style="color:#FFFFFF"');} ?> > [3] </a>
<a href=pageArchive4.php <?php if($NumPageEnCours == 4){ echo('style="color:#FFFFFF"');} ?> > [4] </a>
<a href=pageArchive5.php <?php if($NumPageEnCours == 5){ echo('style="color:#FFFFFF"');} ?> > [5] </a>
