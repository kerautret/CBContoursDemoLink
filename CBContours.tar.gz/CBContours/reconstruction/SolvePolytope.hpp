#ifndef CREERPOLYTOPE_H
#define CREERPOLYTOPE_H

#include <cmath>
#include <list>
#include<Droite.hpp>
#include<Pixel.hpp>

/** classe d�finit le point intersection de deux droites
 */
class Intersection {
	//Membres
	Droite* d1;
	Droite* d2;
	double XX;
	double YY;
	bool existe;
	public:
	//Constructeurs
	Intersection(Droite*,Droite*);
	//Destructeur
	~Intersection();
	//Accesseurs
	Droite& getD1();
	Droite& getD2();
	double getX();
	double getY();
	//Modifier
	void setD1(Droite*);
	void setD2(Droite*);
};

/** classe calculant l'intersection de droites avec le polytope actuel
 */
class SolvePolytope {
	
	//Membres de la classe
	std::list<Droite> LD;
	std::list<Intersection> LI;
	bool estInfini;
	Droite* dalpha; //c�t� du polytope infini 1
	Droite* dbeta;  //c�t� du polytope infini 2
	int demiplanpositif;

	public:
	SolvePolytope();
	SolvePolytope(int);
	~SolvePolytope();

	//Accesseurs
	bool getEstInfini();
	std::list<Intersection> getLI();
	std::list<Droite> getLD();

	//algorithme it�ratif qui met � jour le polytope � l'ajout d'une nouvelle contrainte (droite)
	bool ajouterDroite(Droite);

	//ajoute le pixel en argument, c�d deux droites en fonction de demiplanpositif ou pas
	bool ajouterPixel(Pixel);

	//lorsque trois droites ont la m�me intersection, retourne la contrainte redondante
	int choixParmisTrois(Droite,Droite,Droite);

	/* Dans le cas de deux contraintes parall�les:
	 * retourne 1: si la deuxieme droite est inutile
	 * retourne 2: si la premi�re droite est inutile
	 * retourne B: si les deux droites d�finissent une bande
	 * retourne !: si les contraintes sont incompatibles
	 */
	char contrainteparallele(Droite,Droite);

	double redim(int);

};

#endif
