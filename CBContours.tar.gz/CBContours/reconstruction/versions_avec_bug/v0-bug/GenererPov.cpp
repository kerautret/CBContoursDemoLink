#include <GenererPov.hpp>

//Constructeurs
GenererPov::GenererPov():ofs("cube.pov"){ }

GenererPov::GenererPov(std::string &n):ofs(n.c_str()){ }

//Destructeur
GenererPov::~GenererPov(){ }

void GenererPov::ecrire_entete_redim(int tail) {
	int tmp,tmp2;
	tmp=(int) (-1.5*tail);
	tmp2= (int) (tail/2);

	//// RECOPIER FICHIER ENTETEPOV
	std::fstream file( "entete_redim.pov" );
	std::string line;
	while( getline( file, line ) ) { ofs << line << std::endl; }
	////

	//std::cout << "** DISTANCE CAMERA: " << tmp << std::endl;
	ofs << "camera { location  <" << tmp2 << " , " << tmp2 << " , " << tmp << " > look_at < " << tmp2 << " , " << tmp2 << " , 0.0 > } \n\n";
}
void GenererPov::ecrire_entete_polytope(int tail) {
	int tmp,tmp2;
	tmp=(int) (-5*tail);
	tmp2= (int) (tail/2);

	//// RECOPIER FICHIER ENTETEPOV
	std::fstream file( "entete_polytope.pov" );
	std::string line;
	while( getline( file, line ) ) { ofs << line << std::endl; }
	////

	//std::cout << "** DISTANCE CAMERA: " << tmp << std::endl;
	ofs << "camera { location  <" << 0.0 << " , " << 0.0 << " , " << tmp << " > look_at < " << 0.0 << " , " << 0.0 << " , 0.0 > } \n\n";
}

//Ajouter une ligne
void GenererPov::ajouterLigne(char* ll) {}

//Dessine le segment (aa,bb) (cc,dd) avec la couleur ee
void GenererPov::dessinerLigne(double aa,double bb,double cc,double dd,double ee) {
		ofs << "segment(" << aa << "," << bb << "," << cc << "," << dd << "," << ee << ")\n";
}

//Dessine le polytope
void GenererPov::dessinerPolytope(std::list<Intersection> LI) {
	if (LI.size() >= 3) {
		int cpt=1;
		std::list<Intersection>::iterator LI_it=LI.begin();
		//on dessine le polygone par triangles
		while (LI_it!=LI.end()) {
			ofs << "polygon { " << 3/*LI.size()*/ ;
			while (cpt <= 3) {
				ofs << ", <" << (*LI_it).getX() << ", " << (*LI_it).getY() << "> ";
				LI_it++; cpt++;
			}
			ofs << " pigment { color rgb <0.6,0.6,0.9> } }\n";
			if (LI_it != LI.end()) { LI_it--; LI_it--; }
			cpt=1;
		}
	}
}

//surcharge de l'operateur << pour ecrire � la vol�e dans le fichier 
GenererPov &GenererPov::operator<<(Pixel const& p){
	int x,y,i; x=p.getX();y=p.getY();i=p.getInf();
	ofs << "pixel(" << x << "," << y << "," << i << ")\n";
	return *this;
}

