 
<a href=pageArchive1.php <?php if($NumPageEnCours == 1){ echo('style="color:#FFFFFF"');} ?> > [1] </a>
<a href=pageArchive2.php <?php if($NumPageEnCours == 2){ echo('style="color:#FFFFFF"');} ?> > [2] </a>
<a href=pageArchive3.php <?php if($NumPageEnCours == 3){ echo('style="color:#FFFFFF"');} ?> > [3] </a>
