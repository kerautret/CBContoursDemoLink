#!/bin/sh




NAME=$1
NAMEBG=$2
WIDTH=$3



PATH_BASE=/home/kerautre/Sites/CBContours  ;


cd ${PATH_BASE};

export LD_LIBRARY_PATH=/usr/local/lib/;




/usr/bin/testSampling  -afficheVecteurisation ${WIDTH} CENTER     -afficheContourXFIG 0 0 -enteteXFIG -estimBCCA ${WIDTH}   -savePolygon FichiersTmp/contourSampled.dat < ${NAME}  > FichiersTmp/tmp.fig 2> FichiersTmp/log.txt

fig2dev -L eps FichiersTmp/tmp.fig  FichiersTmp/tmp.eps 

if( test $# -eq 4 )
then 
  /usr/local/bin/testErrorMeasure -polygonA FichiersTmp/contourSampled.dat 0 1  -polygonB ${NAME} 0 1 2> FichiersTmp/logErrorHausdorff.txt;
fi


echo "Curvature Based Contour Reconstruction E=${WIDTH} <BR>" > FichiersTmp/info.txt  ;
cat FichiersTmp/log.txt |grep "of segments" >> FichiersTmp/info.txt; 
echo "<BR> " >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "of arcs" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Curvature BCC" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Segmentation time:" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Execution time:" >> FichiersTmp/info.txt; 
echo "<BR>" >> FichiersTmp/info.txt;
cat FichiersTmp/log.txt |grep "Nb points" >> FichiersTmp/info.txt; 


if( test $# -eq 4 )
then 
ERR=$(cat FichiersTmp/logErrorHausdorff.txt | grep "Hausdorff error" | cut -d " " -f 8); 
echo " Hausdorff error: ${ERR} " >> FichiersTmp/info.txt ;
fi



# Sauvegarde des fichiers sources dans l'archive
cp ${NAME} FichiersTmp/contourSRC.fc;
/usr/local/bin/freeman2pgm -d 2 -auto_center   < FichiersTmp/contourSRC.fc  > FichiersTmp/contourSRC.pgm 
convert FichiersTmp/contourSRC.pgm FichiersTmp/contourSRC.gif;


epstopdf  FichiersTmp/tmp.eps;
pdftoppm FichiersTmp/tmp.pdf FichiersTmp/tmp.ppm ;
convert FichiersTmp/tmp.ppm-1.ppm FichiersTmp/tmp.gif;









